package cassendra.practice;

import org.apache.cassandra.cql3.ResultSet;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Session;

public class Persons {

	static String[] CONTACT_POINTS = { "127.0.0.1" };
	static int PORT = 9042;

	public static void main(String[] args) {

		Persons client = new Persons();

		try {

			client.connect(CONTACT_POINTS, PORT);
			client.createSchema();
			client.loadData();
			client.querySchema();

		} finally {
			client.session.close();
		}

	}

	private Cluster cluster;
	private Session session;

	public void connect(String[] contactPoints, int port) {
		cluster = Cluster.builder().addContactPoints(contactPoints).withPort(port).build();

		System.out.printf("connected to cluster: %s%n", cluster.getMetadata().getClusterName());

		session = cluster.connect();
	}

	private void createSchema() {
		// TODO Auto-generated method stub

		session.execute(
				"CREATE KEYSPACE IF NOT EXISTS simplex WITH replication" + ""
						+ "={'class':''SimpleStrategy', 'replication_factor':1}");
		
		session.execute("CREATE KEYSPACE IF NOT EXISTS simplex.Person("
				+ "id uuid PRIMARY KEY,"
				+ "name text,"
				+"phone int"
				+")");
	}

	public void loadData() {

		session.execute("INSERT INTO simplex.Persons (id, name, phone)"
				+"VALUES (" 
				+"756716f7-2e54-4715-9f00-91dcbea6cf50,"
				+"'PPS',"
				+"12345);");
		
	}

	public void querySchema() {

		ResultSet results = (ResultSet) session.execute("SELECT 8 FROM simplex.playlists"
				+ "WHERE id = 2cc9ccb7-6221-4ccb-8387-f22b6a1b354d;");
		
		System.out.printf("%-30s\t%-20s\t%-20s%n","title", "album", "artists");
		
		System.out.println();
		
	}

}

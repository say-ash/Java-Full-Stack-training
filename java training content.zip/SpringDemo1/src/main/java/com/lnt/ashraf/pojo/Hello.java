package com.lnt.ashraf.pojo;

public class Hello {

	private String message;
	
	public Hello() {
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public Hello(int x) {
	
		System.out.println(x);
		System.out.println("hello constructor");
	}
	public void sayHello() {
		System.out.println("Hello Spring");
	}
	
	public void initBean() {
		System.out.println("Bean Created");
	}
	
	public void myLastWish(){
		System.out.println("killed");
	}
}

package com.lnt.ashraf.pojo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class A {  
	@Autowired
B b;  
A(){
	System.out.println("a is created");
}  
public B getB() {  
    return b;  
}  
public void setB(B b) {  
    this.b = b;  
}  
void print(){
	System.out.println("hello a");
}  
public void display(){  
    print();  
    b.print();  
}  
}  
package com.lnt.calculator;

public interface TV {

	public void getName(String name, int price);
}

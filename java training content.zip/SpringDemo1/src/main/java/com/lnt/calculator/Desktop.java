package com.lnt.calculator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Desktop {

	private String name;
	private int price;
	/*@Qualifier("onida")*/
	@Autowired
	private TV tv;
	
	public void getTVName(String name, int price) {
		tv.getName(name,price);
	}
	
}

package com.lnt.calculator;

import org.springframework.stereotype.Component;

@Component("onida")
public class Onida implements TV{

	public void getName(String name, int price) {
		System.out.println("TV: "+name+"\n"+"Price: "+price);
	}

}

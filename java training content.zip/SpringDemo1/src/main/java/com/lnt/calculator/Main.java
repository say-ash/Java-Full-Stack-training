package com.lnt.calculator;


import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		AbstractApplicationContext con = new ClassPathXmlApplicationContext("bean3.xml");
		Desktop des = con.getBean(Desktop.class);
		des.getTVName("Onida",20000);
		
		
	}
}


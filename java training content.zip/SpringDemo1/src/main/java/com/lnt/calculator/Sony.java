package com.lnt.calculator;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Primary
@Component("sony")
public class Sony implements TV {

	public void getName(String name, int price) {
		System.out.println("hello sony");
		System.out.println("TV: "+name+"\n"+"Price: "+price);
		
	}
	
}

package com.lti.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import com.lti.model.User;

@Component
public class UserDao implements InterfaceUserDao {

	List<User> list = new ArrayList<User>(Arrays.asList(new User("ashraf","mum","987461254")));
	public boolean saveUser(User u) {
		return list.add(u);
	}

	public List<User> viewUserDetails() {
		System.out.println("in viewDetails: "+list.get(0) );
		return list;
	}
	
}

package com.lti.model;

public class User {

	private String name;
	private String city;
	private String contact;
	
	public User() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public User(String name, String city, String contact) {
		super();
		this.name = name;
		this.city = city;
		this.contact = contact;
	}

	@Override
	public String toString() {
		return "User [name=" + name + ", city=" + city + ", contact=" + contact + "]";
	}

	
	
	
}

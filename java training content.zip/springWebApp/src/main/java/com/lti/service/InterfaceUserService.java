package com.lti.service;

import java.util.List;

import com.lti.model.User;

public interface InterfaceUserService {

	boolean saveUser(User u);
	List<User> viewUserDetails();
	
}

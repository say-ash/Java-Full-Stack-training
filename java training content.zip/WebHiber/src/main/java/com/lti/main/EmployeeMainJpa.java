package com.lti.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.lti.entity.Address1;
import com.lti.entity.User;

public class EmployeeMainJpa {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("testdemo");
		System.out.println("factory");
		
		EntityManager em= emf.createEntityManager();
		EntityTransaction etx=em.getTransaction();
		etx.begin();
		
		User user=new User("Yash");
		
		Address1 address=new Address1("Ambernath","504","Maharashtra");
		
		user.setAddress(address);
		
		em.persist(user);
		/*
		 * Address address = new Address("mh",4215); EmployeeAnnotation ea=new
		 * EmployeeAnnotation(2,"yash","mumbai"); ea.setAddress(address);
		 * em.persist(ea);
		 */
		/*
		 * EmployeeAnnotation ea=em.find(EmployeeAnnotation.class, 2);
		 * System.out.println(ea); ea.getAddress().getPincode();
		 */
		etx.commit();
		em.close();
		emf.close();
	}
}

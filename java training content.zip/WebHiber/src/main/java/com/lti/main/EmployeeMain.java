package com.lti.main;

import com.lti.entity.EmployeeAnnotation;
import com.lti.service.EmployeeServce;

public class EmployeeMain {
	public static void main(String[] args) {/*
		EmployeeAnnotation employee = new EmployeeAnnotation(1,"Rohan","nashik");
		EmployeeServce empser=new EmployeeServce();
		int res=empser.addEmployee(employee);
		if(res==1)
		{
			System.out.println("ok");
		}
		else
		{
			System.out.println("bad");
		}
	*/}
}

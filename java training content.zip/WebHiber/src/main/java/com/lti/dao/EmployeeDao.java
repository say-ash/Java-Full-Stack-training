package com.lti.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.lti.entity.Employee;
import com.lti.entity.EmployeeAnnotation;
import com.lti.util.MyDataSource;

public class EmployeeDao {/*

	SessionFactory factory=MyDataSource.getFactory();
	public int saveEmployee(EmployeeAnnotation employee) {
		Session session = factory.openSession();
		System.out.println(employee +"dao");
		//put employee in table
		EmployeeAnnotation emp = employee;
		Transaction tx = session.beginTransaction();
		Integer x=(Integer)session.save(emp);
		//emp.setCity("amb");
		//session.evict(emp);
		//session.remove(x);
		boolean b = session.isDirty();
		System.out.println(b);
		tx.commit();
		session.remove(emp);
		session.close();
		return x;

	}
	public void getEmployee(int id) {
		Session session = factory.openSession(); //getCurrentSession(); //automatically closes connection
		EmployeeAnnotation ee=session.get(EmployeeAnnotation.class, id);
		ee.setCity("pune");
		Transaction tx = session.beginTransaction();
		
		//session.evict(ee);
		System.out.println(ee);

		session.update(ee); 
		tx.commit();
		session.close();
	}

	public static void main(String[] args) {
		new EmployeeDao().getEmployee(14);
	}
*/}

package com.ashraf.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;


import com.ashraf.entity.Address;
import com.ashraf.entity.Employee;
import com.ashraf.entity.EmployeeAnnotation;
import com.ashraf.service.EmployeeService;

public class EmployeeMain {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("lntdemo");
		System.out.println("hi");
		/*EntityManager em = emf.createEntityManager();
		EntityTransaction etx = em.getTransaction();
		etx.begin();
		
		Address add = new Address("Mumbai","Maharashtra","451254");
		EmployeeAnnotation ea = new EmployeeAnnotation(1,"ashraf", add);

		em.persist(ea);
		
		
		etx.commit();
		em.close();
		emf.close();*/
	}

}

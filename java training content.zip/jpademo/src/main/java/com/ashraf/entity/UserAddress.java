package com.ashraf.entity;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="USERADDRESS")
public class UserAddress {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="USERADDRESS_ID")
	private int id;
	
	private String street;
	
	
	
	
}

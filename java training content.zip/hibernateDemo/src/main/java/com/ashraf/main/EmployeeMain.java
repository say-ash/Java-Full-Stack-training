package com.ashraf.main;

import com.ashraf.entity.Employee;
import com.ashraf.entity.EmployeeAnnotation;
import com.ashraf.service.EmployeeService;

public class EmployeeMain {

	public static void main(String[] args) {
		
		EmployeeAnnotation employee = new EmployeeAnnotation(8,"yash","mumbai");
		EmployeeService empService = new EmployeeService();
		int res = empService.addEmployee(employee);
		if(res==1) {
			System.out.println("ok");
		}
		else {
			System.out.println("not ok");
		}

	}

}

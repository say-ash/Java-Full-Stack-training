package com.ashraf.dao;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.ashraf.entity.Employee;
import com.ashraf.entity.EmployeeAnnotation;
import com.ashraf.util.MyDataSource;

public class EmployeeDao {

	SessionFactory factory = MyDataSource.getFactory();
	public int saveEmployee(EmployeeAnnotation employee) {
		Session session = factory.openSession();
		System.out.println("dao: "+employee);
		Transaction tx = session.beginTransaction();
		
		//session.save(employee);
	//	session.saveOrUpdate(employee);
		System.out.println(session.get(EmployeeAnnotation.class, 8));
	//	session.update(employee);
	//	session.delete(employee);
	//	session.evict(employee);
	//	employee.setCity("UP");
	//	if(session.isDirty())
	//		System.out.println("true");
	//	else 
	//		System.out.println("false");
		tx.commit();
	//	session.clear();
		session.close();
		return 1;
	}
}

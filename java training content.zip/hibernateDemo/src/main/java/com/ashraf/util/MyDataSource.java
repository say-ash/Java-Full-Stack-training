package com.ashraf.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class MyDataSource {
	
	private static SessionFactory factory;
	public static SessionFactory getFactory() {
		return factory;
	}
	static {
		Configuration config = new Configuration();
		config.configure();
		System.out.println("Configured");
		factory = config.buildSessionFactory();
	}
}

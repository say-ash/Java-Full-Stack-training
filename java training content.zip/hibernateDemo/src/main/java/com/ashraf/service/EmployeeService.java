package com.ashraf.service;

import com.ashraf.dao.EmployeeDao;
import com.ashraf.entity.Employee;
import com.ashraf.entity.EmployeeAnnotation;

public class EmployeeService {

	public int addEmployee(EmployeeAnnotation employee) {
		System.out.println("service: "+employee);
		
		EmployeeDao empDao = new EmployeeDao();
		empDao.saveEmployee(employee);
		return 1;
	}
}

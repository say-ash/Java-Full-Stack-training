package com.ashraf.aop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		
		ApplicationContext context = new AnnotationConfigApplicationContext(AopApp.class);
	      
	      Student student = context.getBean(Student.class);
	      student.setAge(30);
	      student.setName("ashraf");
	      student.getName();
	      System.out.println(student);
	      student.printThrowException();
	}

}

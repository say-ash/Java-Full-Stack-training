package com.ashraf.aop;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class Logging {

	public Logging() {
	
		System.out.println("Logging...");
	}
	@Pointcut("execution(* com.ashraf.aop.*.*(..))")
	public void adviceForLogging() {
	
	}
	
	@Before("adviceForLogging()")
	public void BeforeAdvice() {
		System.out.println("Going to setup student profile.");
	}
	/*
	@Around(value = "")*/
	
	@AfterReturning(pointcut = "adviceForLogging()", returning = "retVal")
	   public void afterReturningAdvice(Object retVal){
	      System.out.println("Returning:" + retVal.toString() );
	   }
	
	@After("adviceForLogging()")
	public void AfterAdvice() {
		System.out.println("Student profile has been setup.");
	}
	
	 @AfterThrowing(pointcut = "adviceForLogging()", throwing = "ex")
	   public void AfterThrowingAdvice(IllegalArgumentException ex){
	      System.out.println("There has been an exception: " + ex.toString());   
	   }
}

package com.employee.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.employee.model.Employee;

@Repository
public class EmployeeDao {

	List<Employee> list = new ArrayList<Employee>();
	public void addEmployee(Employee e) {
		
		list.add(e);
		
	}
	
	public List<Employee> viewEmployees() {
		return list;
	}

}

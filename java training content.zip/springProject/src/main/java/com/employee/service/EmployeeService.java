package com.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.employee.dao.EmployeeDao;
import com.employee.model.Employee;


@Primary
@Component
public class EmployeeService implements EmployeeServiceI {


	@Autowired
	private EmployeeDao empDao;

	public List<Employee> viewEmployees() {
		
		return empDao.viewEmployees();
	}

	public boolean addEmployee(Employee e) {
	
		System.out.println(e);
		empDao.addEmployee(e);
		return false;
	}
	
}

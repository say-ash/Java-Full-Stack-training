package com.employee.app;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.*")
@org.springframework.context.annotation.Configuration
public class MyConfiguration {

	
}

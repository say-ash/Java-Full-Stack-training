package com.employee.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;

import com.employee.app.MyConfiguration;
import com.employee.view.EmployeeView;

public class EmployeeApp {

	public static void main(String[] args) {

		ApplicationContext context = new AnnotationConfigApplicationContext(MyConfiguration.class);
		EmployeeView empView = context.getBean(EmployeeView.class);
		empView.displayOption();
		

	}

}

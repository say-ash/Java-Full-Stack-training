package com.employee.view;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.employee.model.Employee;
import com.employee.service.EmployeeService;
import com.employee.service.EmployeeServiceI;

@Component
public class EmployeeView {
	String c;
	@Autowired
	private EmployeeService empService;
	
	public void displayOption() {
		 
		do {
		System.out.println("Enter your choice");
		System.out.println("1. Add an Employee\n2. View Employee Details");
		Scanner sc = new Scanner(System.in);
		int ch = sc.nextInt();
		switch(ch){
			case 1: 
					{
					System.out.println("Enter employee name");
					String name = sc.next();
					System.out.println("Enter city");
					String city = sc.next();
					Employee e = new Employee();
					e.setName(name);
					e.setCity(city);
					boolean b = empService.addEmployee(e);
					if(b==true) {
						System.out.println("Record saved...");
					}
					else {
						System.out.println("Record not saved...");
					}
					break;
					}
			case 2: 
				{
					List<Employee> list = empService.viewEmployees();
					System.out.println(list);			
					break;
				}
		}
		
		System.out.println("Do you want to continue(y/n)");
		 c = sc.next();
		
	}while(c.equals("y"));
	
		System.out.println("Thank you");
	}
}

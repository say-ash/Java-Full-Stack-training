package com.harsh.employee;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

@Path("employee")
public class EmployeeController {

	@GET
	@Path("getemppath/{age}/{gender}")
	public String getEmployeePathParam(@PathParam("age") int age,@PathParam("gender") String gender)
	{
		return "Path Employee"+" : "+age +" : "+gender.toUpperCase(); 
	}
	
	@GET
	@Path("getempquery")
	public String getEmployeeQueryParam(@QueryParam("age") int age,@QueryParam("gender") String gender)
	{
		return "Query Employee"+" : "+age +" : "+gender.toUpperCase();
	}
}

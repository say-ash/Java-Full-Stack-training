package com.harsh.hello;

import javax.jws.WebService;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

@WebService
@Path("/hello")
public class HelloWorld 
{
	@GET
	@Path("get1")
	public String helloget1() {
		return "Hello rest world-GET 1";
	}
	
	@GET
	@Path("get2")
	public String helloget2() {
		return "Hello rest world-GET 2";
	}
	
	
	@POST
	@Path("post1")
	public String helloPost1(@MatrixParam(value = "name") String name) {
		return "Hello rest world-POST 1 " +name ;
	}
	
	@POST
	@Path("post2")
	public String helloPost() {
		return "Hello rest world-POST 2";
	}
	
	
	@PUT
	public String helloPut() {
		return "Hello rest world-PUT";
	}
	
	@DELETE
	@Path("delete")
	public String helloDelete() {
		return "Hello rest world-Delete";
	}
}

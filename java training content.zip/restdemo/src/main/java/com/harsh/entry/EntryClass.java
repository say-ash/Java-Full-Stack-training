package com.harsh.entry;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("rest")
public class EntryClass extends Application{
	

}

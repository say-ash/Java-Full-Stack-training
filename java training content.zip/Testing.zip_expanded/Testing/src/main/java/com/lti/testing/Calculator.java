package com.lti.testing;

public class Calculator {

	
	public int add(int a,int b) {
		return a+b;
	}
	public int substract(int a,int b) {
		assert(b>a):"b is greater than a";
		return a-b;
	}
	
	
}

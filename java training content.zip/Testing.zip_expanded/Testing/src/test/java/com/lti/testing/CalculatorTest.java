package com.lti.testing;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
public class CalculatorTest {
	
	private static Calculator cal;
	@BeforeClass
	public static void setUpClass() {	
		System.out.println("before class");
		cal=new Calculator();
	}
	@AfterClass
	public static void getUpClass() {
		System.out.println("after class");
		//assertEquals(expectedvalue, actual);
	}
	@Before	
	public void beforeTest() {
		System.out.println("before");
	}
	@After
	public void afterTest() {
		System.out.println("after");
	}
	@Test
	public void TestMethodAdd() {
		System.out.println("Addition");
		int actualvalue=new Calculator().add(2, 4);
		int expectedvalue=4;
		assertEquals("failed boss",actualvalue, expectedvalue);
	}
}

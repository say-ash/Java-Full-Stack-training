package web.services;



public class HelloPunlisher {

	public static void main(String[] args) {
		javax.xml.ws.Endpoint.publish("http://172.21.142.37:8250/ws/hello", new HelloWorld());
	}
}

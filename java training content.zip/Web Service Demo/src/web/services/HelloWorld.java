package web.services;

import javax.jws.WebService;

@WebService(endpointInterface = "com.xignite.www.services.InterfaceHelloWorld")
public class HelloWorld implements InterfaceHelloWorld {

	@Override
	public String getHelloWorldAsString(String name) {
		
		return "hello "+name;
	}

}

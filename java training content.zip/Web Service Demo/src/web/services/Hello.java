package web.services;

import java.rmi.RemoteException;

import com.xignite.www.services.CrossRate;
import com.xignite.www.services.Currencies;
import com.xignite.www.services.XigniteCurrenciesSoapProxy;

public class Hello {

	public static void main(String[] args) throws RemoteException {
		XigniteCurrenciesSoapProxy p = new XigniteCurrenciesSoapProxy();
		CrossRate cr = p.getRawCrossRate(Currencies.AED, Currencies.INR);
		System.out.println(cr.getAsk()); 

	}

}

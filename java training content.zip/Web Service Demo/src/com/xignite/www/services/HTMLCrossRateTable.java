/**
 * HTMLCrossRateTable.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.xignite.www.services;

public class HTMLCrossRateTable  extends com.xignite.www.services.Common  implements java.io.Serializable {
    private java.lang.String HTML;

    public HTMLCrossRateTable() {
    }

    public HTMLCrossRateTable(
           com.xignite.www.services.OutcomeTypes outcome,
           java.lang.String message,
           java.lang.String identity,
           double delay,
           java.lang.String HTML) {
        super(
            outcome,
            message,
            identity,
            delay);
        this.HTML = HTML;
    }


    /**
     * Gets the HTML value for this HTMLCrossRateTable.
     * 
     * @return HTML
     */
    public java.lang.String getHTML() {
        return HTML;
    }


    /**
     * Sets the HTML value for this HTMLCrossRateTable.
     * 
     * @param HTML
     */
    public void setHTML(java.lang.String HTML) {
        this.HTML = HTML;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HTMLCrossRateTable)) return false;
        HTMLCrossRateTable other = (HTMLCrossRateTable) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.HTML==null && other.getHTML()==null) || 
             (this.HTML!=null &&
              this.HTML.equals(other.getHTML())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getHTML() != null) {
            _hashCode += getHTML().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HTMLCrossRateTable.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HTMLCrossRateTable"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HTML");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HTML"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

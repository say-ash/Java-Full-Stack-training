/**
 * XigniteCurrencies.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.xignite.www.services;

public interface XigniteCurrencies extends javax.xml.rpc.Service {

/**
 * Provide real-time currency foreign exchange information and calculations.
 */
    public java.lang.String getXigniteCurrenciesSoapAddress();

    public com.xignite.www.services.XigniteCurrenciesSoap getXigniteCurrenciesSoap() throws javax.xml.rpc.ServiceException;

    public com.xignite.www.services.XigniteCurrenciesSoap getXigniteCurrenciesSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}

/**
 * CrossRateTableLineWithBidAsk.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.xignite.www.services;

public class CrossRateTableLineWithBidAsk  extends com.xignite.www.services.Common  implements java.io.Serializable {
    private com.xignite.www.services.Currency from;

    private com.xignite.www.services.CrossRate[] exchangeRates;

    public CrossRateTableLineWithBidAsk() {
    }

    public CrossRateTableLineWithBidAsk(
           com.xignite.www.services.OutcomeTypes outcome,
           java.lang.String message,
           java.lang.String identity,
           double delay,
           com.xignite.www.services.Currency from,
           com.xignite.www.services.CrossRate[] exchangeRates) {
        super(
            outcome,
            message,
            identity,
            delay);
        this.from = from;
        this.exchangeRates = exchangeRates;
    }


    /**
     * Gets the from value for this CrossRateTableLineWithBidAsk.
     * 
     * @return from
     */
    public com.xignite.www.services.Currency getFrom() {
        return from;
    }


    /**
     * Sets the from value for this CrossRateTableLineWithBidAsk.
     * 
     * @param from
     */
    public void setFrom(com.xignite.www.services.Currency from) {
        this.from = from;
    }


    /**
     * Gets the exchangeRates value for this CrossRateTableLineWithBidAsk.
     * 
     * @return exchangeRates
     */
    public com.xignite.www.services.CrossRate[] getExchangeRates() {
        return exchangeRates;
    }


    /**
     * Sets the exchangeRates value for this CrossRateTableLineWithBidAsk.
     * 
     * @param exchangeRates
     */
    public void setExchangeRates(com.xignite.www.services.CrossRate[] exchangeRates) {
        this.exchangeRates = exchangeRates;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CrossRateTableLineWithBidAsk)) return false;
        CrossRateTableLineWithBidAsk other = (CrossRateTableLineWithBidAsk) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.from==null && other.getFrom()==null) || 
             (this.from!=null &&
              this.from.equals(other.getFrom()))) &&
            ((this.exchangeRates==null && other.getExchangeRates()==null) || 
             (this.exchangeRates!=null &&
              java.util.Arrays.equals(this.exchangeRates, other.getExchangeRates())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getFrom() != null) {
            _hashCode += getFrom().hashCode();
        }
        if (getExchangeRates() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getExchangeRates());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getExchangeRates(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CrossRateTableLineWithBidAsk.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTableLineWithBidAsk"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("from");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "From"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Currency"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exchangeRates");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ExchangeRates"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRate"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRate"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

/**
 * XigniteCurrenciesLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.xignite.www.services;

public class XigniteCurrenciesLocator extends org.apache.axis.client.Service implements com.xignite.www.services.XigniteCurrencies {

/**
 * Provide real-time currency foreign exchange information and calculations.
 */

    public XigniteCurrenciesLocator() {
    }


    public XigniteCurrenciesLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public XigniteCurrenciesLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for XigniteCurrenciesSoap
    private java.lang.String XigniteCurrenciesSoap_address = "http://www.xignite.com/xcurrencies.asmx";

    public java.lang.String getXigniteCurrenciesSoapAddress() {
        return XigniteCurrenciesSoap_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String XigniteCurrenciesSoapWSDDServiceName = "XigniteCurrenciesSoap";

    public java.lang.String getXigniteCurrenciesSoapWSDDServiceName() {
        return XigniteCurrenciesSoapWSDDServiceName;
    }

    public void setXigniteCurrenciesSoapWSDDServiceName(java.lang.String name) {
        XigniteCurrenciesSoapWSDDServiceName = name;
    }

    public com.xignite.www.services.XigniteCurrenciesSoap getXigniteCurrenciesSoap() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(XigniteCurrenciesSoap_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getXigniteCurrenciesSoap(endpoint);
    }

    public com.xignite.www.services.XigniteCurrenciesSoap getXigniteCurrenciesSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.xignite.www.services.XigniteCurrenciesSoapStub _stub = new com.xignite.www.services.XigniteCurrenciesSoapStub(portAddress, this);
            _stub.setPortName(getXigniteCurrenciesSoapWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setXigniteCurrenciesSoapEndpointAddress(java.lang.String address) {
        XigniteCurrenciesSoap_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.xignite.www.services.XigniteCurrenciesSoap.class.isAssignableFrom(serviceEndpointInterface)) {
                com.xignite.www.services.XigniteCurrenciesSoapStub _stub = new com.xignite.www.services.XigniteCurrenciesSoapStub(new java.net.URL(XigniteCurrenciesSoap_address), this);
                _stub.setPortName(getXigniteCurrenciesSoapWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("XigniteCurrenciesSoap".equals(inputPortName)) {
            return getXigniteCurrenciesSoap();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://www.xignite.com/services/", "XigniteCurrencies");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://www.xignite.com/services/", "XigniteCurrenciesSoap"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("XigniteCurrenciesSoap".equals(portName)) {
            setXigniteCurrenciesSoapEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}

/**
 * CurrencyItem.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.xignite.www.services;

public class CurrencyItem  implements java.io.Serializable {
    private java.lang.String symbol;

    private java.lang.String name;

    private java.lang.String plural;

    private boolean supported;

    private boolean active;

    private java.lang.String activeMessage;

    private com.xignite.www.services.Country[] countries;

    public CurrencyItem() {
    }

    public CurrencyItem(
           java.lang.String symbol,
           java.lang.String name,
           java.lang.String plural,
           boolean supported,
           boolean active,
           java.lang.String activeMessage,
           com.xignite.www.services.Country[] countries) {
           this.symbol = symbol;
           this.name = name;
           this.plural = plural;
           this.supported = supported;
           this.active = active;
           this.activeMessage = activeMessage;
           this.countries = countries;
    }


    /**
     * Gets the symbol value for this CurrencyItem.
     * 
     * @return symbol
     */
    public java.lang.String getSymbol() {
        return symbol;
    }


    /**
     * Sets the symbol value for this CurrencyItem.
     * 
     * @param symbol
     */
    public void setSymbol(java.lang.String symbol) {
        this.symbol = symbol;
    }


    /**
     * Gets the name value for this CurrencyItem.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this CurrencyItem.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the plural value for this CurrencyItem.
     * 
     * @return plural
     */
    public java.lang.String getPlural() {
        return plural;
    }


    /**
     * Sets the plural value for this CurrencyItem.
     * 
     * @param plural
     */
    public void setPlural(java.lang.String plural) {
        this.plural = plural;
    }


    /**
     * Gets the supported value for this CurrencyItem.
     * 
     * @return supported
     */
    public boolean isSupported() {
        return supported;
    }


    /**
     * Sets the supported value for this CurrencyItem.
     * 
     * @param supported
     */
    public void setSupported(boolean supported) {
        this.supported = supported;
    }


    /**
     * Gets the active value for this CurrencyItem.
     * 
     * @return active
     */
    public boolean isActive() {
        return active;
    }


    /**
     * Sets the active value for this CurrencyItem.
     * 
     * @param active
     */
    public void setActive(boolean active) {
        this.active = active;
    }


    /**
     * Gets the activeMessage value for this CurrencyItem.
     * 
     * @return activeMessage
     */
    public java.lang.String getActiveMessage() {
        return activeMessage;
    }


    /**
     * Sets the activeMessage value for this CurrencyItem.
     * 
     * @param activeMessage
     */
    public void setActiveMessage(java.lang.String activeMessage) {
        this.activeMessage = activeMessage;
    }


    /**
     * Gets the countries value for this CurrencyItem.
     * 
     * @return countries
     */
    public com.xignite.www.services.Country[] getCountries() {
        return countries;
    }


    /**
     * Sets the countries value for this CurrencyItem.
     * 
     * @param countries
     */
    public void setCountries(com.xignite.www.services.Country[] countries) {
        this.countries = countries;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CurrencyItem)) return false;
        CurrencyItem other = (CurrencyItem) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.symbol==null && other.getSymbol()==null) || 
             (this.symbol!=null &&
              this.symbol.equals(other.getSymbol()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.plural==null && other.getPlural()==null) || 
             (this.plural!=null &&
              this.plural.equals(other.getPlural()))) &&
            this.supported == other.isSupported() &&
            this.active == other.isActive() &&
            ((this.activeMessage==null && other.getActiveMessage()==null) || 
             (this.activeMessage!=null &&
              this.activeMessage.equals(other.getActiveMessage()))) &&
            ((this.countries==null && other.getCountries()==null) || 
             (this.countries!=null &&
              java.util.Arrays.equals(this.countries, other.getCountries())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSymbol() != null) {
            _hashCode += getSymbol().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getPlural() != null) {
            _hashCode += getPlural().hashCode();
        }
        _hashCode += (isSupported() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isActive() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getActiveMessage() != null) {
            _hashCode += getActiveMessage().hashCode();
        }
        if (getCountries() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCountries());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCountries(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CurrencyItem.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CurrencyItem"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("symbol");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("plural");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Plural"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("supported");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Supported"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("active");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Active"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activeMessage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ActiveMessage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("countries");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Countries"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Country"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Country"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

/**
 * XigniteCurrenciesSoapStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.xignite.www.services;

public class XigniteCurrenciesSoapStub extends org.apache.axis.client.Stub implements com.xignite.www.services.XigniteCurrenciesSoap {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[56];
        _initOperationDesc1();
        _initOperationDesc2();
        _initOperationDesc3();
        _initOperationDesc4();
        _initOperationDesc5();
        _initOperationDesc6();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ListCurrencies");
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CurrencyList"));
        oper.setReturnClass(com.xignite.www.services.CurrencyList.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ListCurrenciesResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ListActiveCurrencies");
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CurrencyList"));
        oper.setReturnClass(com.xignite.www.services.CurrencyList.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ListActiveCurrenciesResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ListOfficialRates");
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "OfficialRates"));
        oper.setReturnClass(com.xignite.www.services.OfficialRates.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ListOfficialRatesResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetUnitOfAccount");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Currency"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AsOfDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "UnitOfAccount"));
        oper.setReturnClass(com.xignite.www.services.UnitOfAccount.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetUnitOfAccountResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ConvertRealTimeValue");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "From"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "To"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Amount"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"), double.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ExchangeConversion"));
        oper.setReturnClass(com.xignite.www.services.ExchangeConversion.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ConvertRealTimeValueResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ConvertHistoricalValue");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "From"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "To"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AsOfDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Amount"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"), double.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ExchangeConversion"));
        oper.setReturnClass(com.xignite.www.services.ExchangeConversion.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ConvertHistoricalValueResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRealTimeForwardRate");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "From"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "To"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ForwardRate"));
        oper.setReturnClass(com.xignite.www.services.ForwardRate.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRealTimeForwardRateResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRealTimeCrossRateAsString");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "From"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "To"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRate"));
        oper.setReturnClass(com.xignite.www.services.CrossRate.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRealTimeCrossRateAsStringResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetLatestCrossRate");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "From"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "To"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRate"));
        oper.setReturnClass(com.xignite.www.services.CrossRate.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetLatestCrossRateResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetLatestCrossRates");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "From"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Tos"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfCrossRate"));
        oper.setReturnClass(com.xignite.www.services.CrossRate[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetLatestCrossRatesResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRate"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRealTimeCrossRate");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "From"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "Currencies"), com.xignite.www.services.Currencies.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "To"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "Currencies"), com.xignite.www.services.Currencies.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRate"));
        oper.setReturnClass(com.xignite.www.services.CrossRate.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRealTimeCrossRateResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRealTimeCrossRateGMT");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "From"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "Currencies"), com.xignite.www.services.Currencies.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "To"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "Currencies"), com.xignite.www.services.Currencies.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRate"));
        oper.setReturnClass(com.xignite.www.services.CrossRate.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRealTimeCrossRateGMTResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRawCrossRate");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "From"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "Currencies"), com.xignite.www.services.Currencies.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "To"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "Currencies"), com.xignite.www.services.Currencies.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRate"));
        oper.setReturnClass(com.xignite.www.services.CrossRate.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRawCrossRateResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRawCrossRates");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbols"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfCrossRate"));
        oper.setReturnClass(com.xignite.www.services.CrossRate[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRawCrossRatesResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRate"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRealTimeCrossRates");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbols"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfCrossRate"));
        oper.setReturnClass(com.xignite.www.services.CrossRate[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRealTimeCrossRatesResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRate"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHistoricalCrossRateTables");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbols"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfCrossRateTable"));
        oper.setReturnClass(com.xignite.www.services.CrossRateTable[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRateTablesResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTable"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[15] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHistoricalCrossRateTablesBidAsk");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbols"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfCrossRateTableWithBidAsk"));
        oper.setReturnClass(com.xignite.www.services.CrossRateTableWithBidAsk[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRateTablesBidAskResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTableWithBidAsk"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[16] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetCurrencyReport");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "From"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "To"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Report"));
        oper.setReturnClass(com.xignite.www.services.Report.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCurrencyReportResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[17] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHistoricalCrossRateTable");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbols"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AsOfDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTable"));
        oper.setReturnClass(com.xignite.www.services.CrossRateTable.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRateTableResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[18] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHistoricalCrossRateTableBidAsk");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbols"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AsOfDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTableWithBidAsk"));
        oper.setReturnClass(com.xignite.www.services.CrossRateTableWithBidAsk.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRateTableBidAskResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[19] = oper;

    }

    private static void _initOperationDesc3(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRealTimeCrossRateTable");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbols"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTable"));
        oper.setReturnClass(com.xignite.www.services.CrossRateTable.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRealTimeCrossRateTableResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[20] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRealTimeCrossRateTableWithBidAsk");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbols"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTableWithBidAsk"));
        oper.setReturnClass(com.xignite.www.services.CrossRateTableWithBidAsk.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRealTimeCrossRateTableWithBidAskResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[21] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetAllCrossRatesForACurrency");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTableLineWithBidAsk"));
        oper.setReturnClass(com.xignite.www.services.CrossRateTableLineWithBidAsk.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetAllCrossRatesForACurrencyResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[22] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRealTimeCrossRateTableAsHTML");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbols"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ColumnHeaderStyle"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "LineHeaderStyle"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CellStyle"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HTMLCrossRateTable"));
        oper.setReturnClass(com.xignite.www.services.HTMLCrossRateTable.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRealTimeCrossRateTableAsHTMLResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[23] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetSimpleRealTimeCrossRateTableAsHTML");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbols"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ColumnHeaderStyle"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "LineHeaderStyle"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CellStyle"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HTMLCrossRateTable"));
        oper.setReturnClass(com.xignite.www.services.HTMLCrossRateTable.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetSimpleRealTimeCrossRateTableAsHTMLResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[24] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHistoricalCrossRateTableAsHTML");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbols"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AsOfDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ColumnHeaderStyle"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "LineHeaderStyle"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CellStyle"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HTMLCrossRateTable"));
        oper.setReturnClass(com.xignite.www.services.HTMLCrossRateTable.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRateTableAsHTMLResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[25] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHistoricalCrossRate");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AsOfDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalCrossRate"));
        oper.setReturnClass(com.xignite.www.services.HistoricalCrossRate.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRateResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[26] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHistoricalCrossRates");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbols"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AsOfDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfHistoricalCrossRate"));
        oper.setReturnClass(com.xignite.www.services.HistoricalCrossRate[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRatesResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalCrossRate"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[27] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHistoricalCrossRateBidAsk");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AsOfDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "FullHistoricalCrossRate"));
        oper.setReturnClass(com.xignite.www.services.FullHistoricalCrossRate.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRateBidAskResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[28] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHistoricalCrossRatesBidAsk");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbols"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AsOfDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfFullHistoricalCrossRate"));
        oper.setReturnClass(com.xignite.www.services.FullHistoricalCrossRate[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRatesBidAskResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "FullHistoricalCrossRate"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[29] = oper;

    }

    private static void _initOperationDesc4(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHistoricalCrossRatesRange");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalCrossRates"));
        oper.setReturnClass(com.xignite.www.services.HistoricalCrossRates.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRatesRangeResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[30] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHistoricalCrossRatesBidAskRange");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "FullHistoricalCrossRates"));
        oper.setReturnClass(com.xignite.www.services.FullHistoricalCrossRates.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRatesBidAskRangeResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[31] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHistoricalCrossRatesAsOf");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"), java.util.Calendar.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "PeriodType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "PeriodTypes"), com.xignite.www.services.PeriodTypes.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Periods"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalCrossRates"));
        oper.setReturnClass(com.xignite.www.services.HistoricalCrossRates.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRatesAsOfResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[32] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHistoricalCrossRatesBidAskAsOf");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"), java.util.Calendar.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "PeriodType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "PeriodTypes"), com.xignite.www.services.PeriodTypes.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Periods"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "FullHistoricalCrossRates"));
        oper.setReturnClass(com.xignite.www.services.FullHistoricalCrossRates.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRatesBidAskAsOfResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[33] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetOfficialCrossRate");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CountryType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "CountryTypes"), com.xignite.www.services.CountryTypes.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "Currencies"), com.xignite.www.services.Currencies.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AsOfDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalCrossRate"));
        oper.setReturnClass(com.xignite.www.services.HistoricalCrossRate.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetOfficialCrossRateResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[34] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetOfficialCrossRates");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CountryType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "CountryTypes"), com.xignite.www.services.CountryTypes.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbols"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AsOfDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfHistoricalCrossRate"));
        oper.setReturnClass(com.xignite.www.services.HistoricalCrossRate[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetOfficialCrossRatesResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalCrossRate"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[35] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetOfficialCrossRateBidAsk");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CountryType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "CountryTypes"), com.xignite.www.services.CountryTypes.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "Currencies"), com.xignite.www.services.Currencies.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AsOfDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "FullHistoricalCrossRate"));
        oper.setReturnClass(com.xignite.www.services.FullHistoricalCrossRate.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetOfficialCrossRateBidAskResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[36] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetOfficialCrossRatesBidAsk");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CountryType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "CountryTypes"), com.xignite.www.services.CountryTypes.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbols"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AsOfDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfFullHistoricalCrossRate"));
        oper.setReturnClass(com.xignite.www.services.FullHistoricalCrossRate[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetOfficialCrossRatesBidAskResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "FullHistoricalCrossRate"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[37] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetMutipleHistoricalCrossRates");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbols"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AsOfDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "MultipleHistoricalCrossRates"));
        oper.setReturnClass(com.xignite.www.services.MultipleHistoricalCrossRates.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetMutipleHistoricalCrossRatesResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[38] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetAverageHistoricalCrossRates");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbols"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfAverageHistoricalCrossRate"));
        oper.setReturnClass(com.xignite.www.services.AverageHistoricalCrossRate[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetAverageHistoricalCrossRatesResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AverageHistoricalCrossRate"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[39] = oper;

    }

    private static void _initOperationDesc5(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetAverageHistoricalCrossRate");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AverageHistoricalCrossRate"));
        oper.setReturnClass(com.xignite.www.services.AverageHistoricalCrossRate.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetAverageHistoricalCrossRateResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[40] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHistoricalMonthlyCrossRatesRange");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "FullHistoricalCrossRates"));
        oper.setReturnClass(com.xignite.www.services.FullHistoricalCrossRates.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalMonthlyCrossRatesRangeResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[41] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetCrossRateChange");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateChange"));
        oper.setReturnClass(com.xignite.www.services.CrossRateChange.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCrossRateChangeResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[42] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetCurrencyChartCustom");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "PeriodType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalPeriodTypes"), com.xignite.www.services.HistoricalPeriodTypes.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Style"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "StockChartStyles"), com.xignite.www.services.StockChartStyles.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Width"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Height"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Design"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "ChartDesign"), com.xignite.www.services.ChartDesign.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalChart"));
        oper.setReturnClass(com.xignite.www.services.HistoricalChart.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCurrencyChartCustomResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[43] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetCurrencyChartCustomBinary");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "PeriodType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalPeriodTypes"), com.xignite.www.services.HistoricalPeriodTypes.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Style"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "StockChartStyles"), com.xignite.www.services.StockChartStyles.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Width"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Height"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Design"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "ChartDesign"), com.xignite.www.services.ChartDesign.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ChartBinary"));
        oper.setReturnClass(com.xignite.www.services.ChartBinary.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCurrencyChartCustomBinaryResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[44] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetCurrencyChart");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "PeriodType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalPeriodTypes"), com.xignite.www.services.HistoricalPeriodTypes.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Style"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "StockChartStyles"), com.xignite.www.services.StockChartStyles.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Width"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Height"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Preset"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalChart"));
        oper.setReturnClass(com.xignite.www.services.HistoricalChart.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCurrencyChartResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[45] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetCurrencyChartBinary");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "PeriodType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalPeriodTypes"), com.xignite.www.services.HistoricalPeriodTypes.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Style"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "StockChartStyles"), com.xignite.www.services.StockChartStyles.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Width"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Height"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Preset"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ChartBinary"));
        oper.setReturnClass(com.xignite.www.services.ChartBinary.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCurrencyChartBinaryResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[46] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetCurrencyIntradayChart");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "TimeZone"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Style"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "StockChartStyles"), com.xignite.www.services.StockChartStyles.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Width"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Height"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "PeriodType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "TickPeriods"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Preset"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CurrencyChartIntraday"));
        oper.setReturnClass(com.xignite.www.services.CurrencyChartIntraday.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCurrencyIntradayChartResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[47] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetCurrencyIntradayChartCustomBinary");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "TimeZone"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Style"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "StockChartStyles"), com.xignite.www.services.StockChartStyles.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Width"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Height"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "PeriodType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "TickPeriods"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Design"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "ChartDesign"), com.xignite.www.services.ChartDesign.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ChartBinary"));
        oper.setReturnClass(com.xignite.www.services.ChartBinary.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCurrencyIntradayChartCustomBinaryResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[48] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetCurrencyIntradayChartCustom");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "TimeZone"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Style"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "StockChartStyles"), com.xignite.www.services.StockChartStyles.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Width"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Height"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "PeriodType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "TickPeriods"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Design"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "ChartDesign"), com.xignite.www.services.ChartDesign.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CurrencyChartIntraday"));
        oper.setReturnClass(com.xignite.www.services.CurrencyChartIntraday.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCurrencyIntradayChartCustomResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[49] = oper;

    }

    private static void _initOperationDesc6(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetChartDesign");
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ChartDesign"));
        oper.setReturnClass(com.xignite.www.services.ChartDesign.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetChartDesignResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[50] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetTick");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Time"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "SingleTick"));
        oper.setReturnClass(com.xignite.www.services.SingleTick.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetTickResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[51] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetTicks");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "TickPrecision"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "TickPeriod"), com.xignite.www.services.TickPeriod.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "TickPeriods"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Ticks"));
        oper.setReturnClass(com.xignite.www.services.Ticks.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetTicksResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[52] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHistoricalTicks");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AsOfDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "TickPrecision"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.xignite.com/services/", "TickPeriod"), com.xignite.www.services.TickPeriod.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "TickPeriods"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Ticks"));
        oper.setReturnClass(com.xignite.www.services.Ticks.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalTicksResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[53] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHistoricalHighLow");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartDateTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndDateTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HighLowTick"));
        oper.setReturnClass(com.xignite.www.services.HighLowTick.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalHighLowResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[54] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetIntradayHighLow");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartDateTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndDateTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HighLowTick"));
        oper.setReturnClass(com.xignite.www.services.HighLowTick.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetIntradayHighLowResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[55] = oper;

    }

    public XigniteCurrenciesSoapStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public XigniteCurrenciesSoapStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public XigniteCurrenciesSoapStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfAverageHistoricalCrossRate");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.AverageHistoricalCrossRate[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "AverageHistoricalCrossRate");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "AverageHistoricalCrossRate");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfChange");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.Change[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Change");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Change");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfCountry");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.Country[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Country");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Country");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfCrossRate");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CrossRate[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRate");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRate");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfCrossRateItem");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CrossRateItem[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateItem");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateItem");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfCrossRateTable");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CrossRateTable[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTable");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTable");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfCrossRateTableLine");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CrossRateTableLine[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTableLine");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTableLine");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfCrossRateTableLineWithBidAsk");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CrossRateTableLineWithBidAsk[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTableLineWithBidAsk");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTableLineWithBidAsk");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfCrossRateTableWithBidAsk");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CrossRateTableWithBidAsk[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTableWithBidAsk");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTableWithBidAsk");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfCurrencyItem");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CurrencyItem[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CurrencyItem");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CurrencyItem");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfExchangeRate");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.ExchangeRate[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ExchangeRate");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ExchangeRate");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfForward");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.Forward[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Forward");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Forward");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfFullCrossRateItem");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.FullCrossRateItem[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "FullCrossRateItem");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "FullCrossRateItem");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfFullHistoricalCrossRate");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.FullHistoricalCrossRate[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "FullHistoricalCrossRate");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "FullHistoricalCrossRate");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfHistoricalCrossRate");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.HistoricalCrossRate[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalCrossRate");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalCrossRate");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfLine");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.Line[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Line");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Line");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfOfficialCountry");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.OfficialCountry[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "OfficialCountry");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "OfficialCountry");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfOfficialCurrency");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.OfficialCurrency[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "OfficialCurrency");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "OfficialCurrency");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ArrayOfTick");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.Tick[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Tick");
            qName2 = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Tick");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "AverageHistoricalCrossRate");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.AverageHistoricalCrossRate.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Change");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.Change.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ChangeTypes");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.ChangeTypes.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ChartBinary");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.ChartBinary.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ChartDesign");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.ChartDesign.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Common");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.Common.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Country");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.Country.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CountryTypes");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CountryTypes.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRate");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CrossRate.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateChange");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CrossRateChange.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateItem");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CrossRateItem.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTable");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CrossRateTable.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTableLine");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CrossRateTableLine.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTableLineWithBidAsk");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CrossRateTableLineWithBidAsk.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRateTableWithBidAsk");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CrossRateTableWithBidAsk.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Currencies");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.Currencies.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Currency");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.Currency.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CurrencyChartIntraday");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CurrencyChartIntraday.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CurrencyItem");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CurrencyItem.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "CurrencyList");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.CurrencyList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ExchangeConversion");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.ExchangeConversion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ExchangeRate");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.ExchangeRate.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Forward");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.Forward.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ForwardRate");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.ForwardRate.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ForwardTypes");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.ForwardTypes.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "FullCrossRateItem");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.FullCrossRateItem.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "FullHistoricalCrossRate");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.FullHistoricalCrossRate.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "FullHistoricalCrossRates");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.FullHistoricalCrossRates.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "HighLowTick");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.HighLowTick.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "HighLowTickTypes");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.HighLowTickTypes.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalChart");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.HistoricalChart.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalCrossRate");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.HistoricalCrossRate.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalCrossRates");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.HistoricalCrossRates.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "HistoricalPeriodTypes");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.HistoricalPeriodTypes.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "HorzAlign");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.HorzAlign.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "HTMLCrossRateTable");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.HTMLCrossRateTable.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "ImageFrameType");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.ImageFrameType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Line");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.Line.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "LinePattern");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.LinePattern.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "LineTypes");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.LineTypes.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "MultipleHistoricalCrossRates");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.MultipleHistoricalCrossRates.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "OfficialCountry");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.OfficialCountry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "OfficialCurrency");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.OfficialCurrency.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "OfficialRates");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.OfficialRates.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "OutcomeTypes");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.OutcomeTypes.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "PeriodTypes");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.PeriodTypes.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "PredefinedLightModel");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.PredefinedLightModel.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "PredefinedProjection");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.PredefinedProjection.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "QuoteTypes");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.QuoteTypes.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Report");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.Report.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "SingleTick");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.SingleTick.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "StockChart");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.StockChart.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "StockChartStyles");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.StockChartStyles.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Tick");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.Tick.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "TickPeriod");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.TickPeriod.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "Ticks");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.Ticks.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.xignite.com/services/", "UnitOfAccount");
            cachedSerQNames.add(qName);
            cls = com.xignite.www.services.UnitOfAccount.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public com.xignite.www.services.CurrencyList listCurrencies() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/ListCurrencies");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ListCurrencies"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CurrencyList) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CurrencyList) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CurrencyList.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CurrencyList listActiveCurrencies() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/ListActiveCurrencies");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ListActiveCurrencies"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CurrencyList) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CurrencyList) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CurrencyList.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.OfficialRates listOfficialRates() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/ListOfficialRates");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ListOfficialRates"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.OfficialRates) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.OfficialRates) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.OfficialRates.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.UnitOfAccount getUnitOfAccount(java.lang.String currency, java.lang.String asOfDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetUnitOfAccount");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetUnitOfAccount"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {currency, asOfDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.UnitOfAccount) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.UnitOfAccount) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.UnitOfAccount.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.ExchangeConversion convertRealTimeValue(java.lang.String from, java.lang.String to, double amount) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/ConvertRealTimeValue");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ConvertRealTimeValue"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {from, to, new java.lang.Double(amount)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.ExchangeConversion) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.ExchangeConversion) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.ExchangeConversion.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.ExchangeConversion convertHistoricalValue(java.lang.String from, java.lang.String to, java.lang.String asOfDate, double amount) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/ConvertHistoricalValue");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ConvertHistoricalValue"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {from, to, asOfDate, new java.lang.Double(amount)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.ExchangeConversion) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.ExchangeConversion) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.ExchangeConversion.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.ForwardRate getRealTimeForwardRate(java.lang.String from, java.lang.String to) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetRealTimeForwardRate");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRealTimeForwardRate"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {from, to});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.ForwardRate) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.ForwardRate) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.ForwardRate.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CrossRate getRealTimeCrossRateAsString(java.lang.String from, java.lang.String to) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetRealTimeCrossRateAsString");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRealTimeCrossRateAsString"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {from, to});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CrossRate) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CrossRate) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CrossRate.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CrossRate getLatestCrossRate(java.lang.String from, java.lang.String to) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetLatestCrossRate");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetLatestCrossRate"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {from, to});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CrossRate) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CrossRate) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CrossRate.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CrossRate[] getLatestCrossRates(java.lang.String from, java.lang.String tos) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetLatestCrossRates");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetLatestCrossRates"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {from, tos});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CrossRate[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CrossRate[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CrossRate[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CrossRate getRealTimeCrossRate(com.xignite.www.services.Currencies from, com.xignite.www.services.Currencies to) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetRealTimeCrossRate");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRealTimeCrossRate"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {from, to});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CrossRate) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CrossRate) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CrossRate.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CrossRate getRealTimeCrossRateGMT(com.xignite.www.services.Currencies from, com.xignite.www.services.Currencies to) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetRealTimeCrossRateGMT");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRealTimeCrossRateGMT"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {from, to});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CrossRate) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CrossRate) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CrossRate.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CrossRate getRawCrossRate(com.xignite.www.services.Currencies from, com.xignite.www.services.Currencies to) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetRawCrossRate");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRawCrossRate"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {from, to});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CrossRate) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CrossRate) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CrossRate.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CrossRate[] getRawCrossRates(java.lang.String symbols) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetRawCrossRates");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRawCrossRates"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbols});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CrossRate[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CrossRate[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CrossRate[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CrossRate[] getRealTimeCrossRates(java.lang.String symbols) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetRealTimeCrossRates");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRealTimeCrossRates"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbols});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CrossRate[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CrossRate[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CrossRate[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CrossRateTable[] getHistoricalCrossRateTables(java.lang.String symbols, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetHistoricalCrossRateTables");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRateTables"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbols, startDate, endDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CrossRateTable[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CrossRateTable[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CrossRateTable[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CrossRateTableWithBidAsk[] getHistoricalCrossRateTablesBidAsk(java.lang.String symbols, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[16]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetHistoricalCrossRateTablesBidAsk");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRateTablesBidAsk"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbols, startDate, endDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CrossRateTableWithBidAsk[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CrossRateTableWithBidAsk[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CrossRateTableWithBidAsk[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.Report getCurrencyReport(java.lang.String from, java.lang.String to, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[17]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetCurrencyReport");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCurrencyReport"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {from, to, startDate, endDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.Report) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.Report) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.Report.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CrossRateTable getHistoricalCrossRateTable(java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[18]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetHistoricalCrossRateTable");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRateTable"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbols, asOfDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CrossRateTable) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CrossRateTable) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CrossRateTable.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CrossRateTableWithBidAsk getHistoricalCrossRateTableBidAsk(java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[19]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetHistoricalCrossRateTableBidAsk");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRateTableBidAsk"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbols, asOfDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CrossRateTableWithBidAsk) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CrossRateTableWithBidAsk) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CrossRateTableWithBidAsk.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CrossRateTable getRealTimeCrossRateTable(java.lang.String symbols) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[20]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetRealTimeCrossRateTable");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRealTimeCrossRateTable"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbols});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CrossRateTable) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CrossRateTable) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CrossRateTable.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CrossRateTableWithBidAsk getRealTimeCrossRateTableWithBidAsk(java.lang.String symbols) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[21]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetRealTimeCrossRateTableWithBidAsk");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRealTimeCrossRateTableWithBidAsk"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbols});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CrossRateTableWithBidAsk) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CrossRateTableWithBidAsk) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CrossRateTableWithBidAsk.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CrossRateTableLineWithBidAsk getAllCrossRatesForACurrency(java.lang.String symbol) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[22]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetAllCrossRatesForACurrency");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetAllCrossRatesForACurrency"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CrossRateTableLineWithBidAsk) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CrossRateTableLineWithBidAsk) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CrossRateTableLineWithBidAsk.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.HTMLCrossRateTable getRealTimeCrossRateTableAsHTML(java.lang.String symbols, java.lang.String columnHeaderStyle, java.lang.String lineHeaderStyle, java.lang.String cellStyle) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[23]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetRealTimeCrossRateTableAsHTML");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetRealTimeCrossRateTableAsHTML"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbols, columnHeaderStyle, lineHeaderStyle, cellStyle});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.HTMLCrossRateTable) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.HTMLCrossRateTable) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.HTMLCrossRateTable.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.HTMLCrossRateTable getSimpleRealTimeCrossRateTableAsHTML(java.lang.String symbols, java.lang.String columnHeaderStyle, java.lang.String lineHeaderStyle, java.lang.String cellStyle) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[24]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetSimpleRealTimeCrossRateTableAsHTML");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetSimpleRealTimeCrossRateTableAsHTML"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbols, columnHeaderStyle, lineHeaderStyle, cellStyle});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.HTMLCrossRateTable) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.HTMLCrossRateTable) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.HTMLCrossRateTable.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.HTMLCrossRateTable getHistoricalCrossRateTableAsHTML(java.lang.String symbols, java.lang.String asOfDate, java.lang.String columnHeaderStyle, java.lang.String lineHeaderStyle, java.lang.String cellStyle) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[25]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetHistoricalCrossRateTableAsHTML");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRateTableAsHTML"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbols, asOfDate, columnHeaderStyle, lineHeaderStyle, cellStyle});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.HTMLCrossRateTable) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.HTMLCrossRateTable) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.HTMLCrossRateTable.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.HistoricalCrossRate getHistoricalCrossRate(java.lang.String symbol, java.lang.String asOfDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[26]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetHistoricalCrossRate");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRate"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, asOfDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.HistoricalCrossRate) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.HistoricalCrossRate) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.HistoricalCrossRate.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.HistoricalCrossRate[] getHistoricalCrossRates(java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[27]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetHistoricalCrossRates");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRates"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbols, asOfDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.HistoricalCrossRate[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.HistoricalCrossRate[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.HistoricalCrossRate[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.FullHistoricalCrossRate getHistoricalCrossRateBidAsk(java.lang.String symbol, java.lang.String asOfDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[28]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetHistoricalCrossRateBidAsk");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRateBidAsk"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, asOfDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.FullHistoricalCrossRate) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.FullHistoricalCrossRate) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.FullHistoricalCrossRate.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.FullHistoricalCrossRate[] getHistoricalCrossRatesBidAsk(java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[29]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetHistoricalCrossRatesBidAsk");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRatesBidAsk"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbols, asOfDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.FullHistoricalCrossRate[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.FullHistoricalCrossRate[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.FullHistoricalCrossRate[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.HistoricalCrossRates getHistoricalCrossRatesRange(java.lang.String symbol, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[30]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetHistoricalCrossRatesRange");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRatesRange"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, startDate, endDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.HistoricalCrossRates) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.HistoricalCrossRates) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.HistoricalCrossRates.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.FullHistoricalCrossRates getHistoricalCrossRatesBidAskRange(java.lang.String symbol, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[31]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetHistoricalCrossRatesBidAskRange");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRatesBidAskRange"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, startDate, endDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.FullHistoricalCrossRates) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.FullHistoricalCrossRates) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.FullHistoricalCrossRates.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.HistoricalCrossRates getHistoricalCrossRatesAsOf(java.lang.String symbol, java.util.Calendar endDate, com.xignite.www.services.PeriodTypes periodType, int periods) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[32]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetHistoricalCrossRatesAsOf");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRatesAsOf"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, endDate, periodType, new java.lang.Integer(periods)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.HistoricalCrossRates) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.HistoricalCrossRates) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.HistoricalCrossRates.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.FullHistoricalCrossRates getHistoricalCrossRatesBidAskAsOf(java.lang.String symbol, java.util.Calendar endDate, com.xignite.www.services.PeriodTypes periodType, int periods) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[33]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetHistoricalCrossRatesBidAskAsOf");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalCrossRatesBidAskAsOf"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, endDate, periodType, new java.lang.Integer(periods)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.FullHistoricalCrossRates) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.FullHistoricalCrossRates) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.FullHistoricalCrossRates.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.HistoricalCrossRate getOfficialCrossRate(com.xignite.www.services.CountryTypes countryType, com.xignite.www.services.Currencies symbol, java.lang.String asOfDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[34]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetOfficialCrossRate");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetOfficialCrossRate"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {countryType, symbol, asOfDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.HistoricalCrossRate) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.HistoricalCrossRate) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.HistoricalCrossRate.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.HistoricalCrossRate[] getOfficialCrossRates(com.xignite.www.services.CountryTypes countryType, java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[35]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetOfficialCrossRates");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetOfficialCrossRates"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {countryType, symbols, asOfDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.HistoricalCrossRate[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.HistoricalCrossRate[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.HistoricalCrossRate[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.FullHistoricalCrossRate getOfficialCrossRateBidAsk(com.xignite.www.services.CountryTypes countryType, com.xignite.www.services.Currencies symbol, java.lang.String asOfDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[36]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetOfficialCrossRateBidAsk");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetOfficialCrossRateBidAsk"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {countryType, symbol, asOfDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.FullHistoricalCrossRate) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.FullHistoricalCrossRate) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.FullHistoricalCrossRate.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.FullHistoricalCrossRate[] getOfficialCrossRatesBidAsk(com.xignite.www.services.CountryTypes countryType, java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[37]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetOfficialCrossRatesBidAsk");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetOfficialCrossRatesBidAsk"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {countryType, symbols, asOfDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.FullHistoricalCrossRate[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.FullHistoricalCrossRate[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.FullHistoricalCrossRate[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.MultipleHistoricalCrossRates getMutipleHistoricalCrossRates(java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[38]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetMutipleHistoricalCrossRates");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetMutipleHistoricalCrossRates"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbols, asOfDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.MultipleHistoricalCrossRates) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.MultipleHistoricalCrossRates) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.MultipleHistoricalCrossRates.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.AverageHistoricalCrossRate[] getAverageHistoricalCrossRates(java.lang.String symbols, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[39]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetAverageHistoricalCrossRates");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetAverageHistoricalCrossRates"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbols, startDate, endDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.AverageHistoricalCrossRate[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.AverageHistoricalCrossRate[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.AverageHistoricalCrossRate[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.AverageHistoricalCrossRate getAverageHistoricalCrossRate(java.lang.String symbol, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[40]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetAverageHistoricalCrossRate");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetAverageHistoricalCrossRate"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, startDate, endDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.AverageHistoricalCrossRate) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.AverageHistoricalCrossRate) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.AverageHistoricalCrossRate.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.FullHistoricalCrossRates getHistoricalMonthlyCrossRatesRange(java.lang.String symbol, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[41]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetHistoricalMonthlyCrossRatesRange");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalMonthlyCrossRatesRange"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, startDate, endDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.FullHistoricalCrossRates) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.FullHistoricalCrossRates) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.FullHistoricalCrossRates.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CrossRateChange getCrossRateChange(java.lang.String symbol) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[42]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetCrossRateChange");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCrossRateChange"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CrossRateChange) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CrossRateChange) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CrossRateChange.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.HistoricalChart getCurrencyChartCustom(java.lang.String symbol, com.xignite.www.services.HistoricalPeriodTypes periodType, java.lang.String startDate, java.lang.String endDate, com.xignite.www.services.StockChartStyles style, int width, int height, com.xignite.www.services.ChartDesign design) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[43]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetCurrencyChartCustom");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCurrencyChartCustom"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, periodType, startDate, endDate, style, new java.lang.Integer(width), new java.lang.Integer(height), design});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.HistoricalChart) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.HistoricalChart) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.HistoricalChart.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.ChartBinary getCurrencyChartCustomBinary(java.lang.String symbol, com.xignite.www.services.HistoricalPeriodTypes periodType, java.lang.String startDate, java.lang.String endDate, com.xignite.www.services.StockChartStyles style, int width, int height, com.xignite.www.services.ChartDesign design) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[44]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetCurrencyChartCustomBinary");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCurrencyChartCustomBinary"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, periodType, startDate, endDate, style, new java.lang.Integer(width), new java.lang.Integer(height), design});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.ChartBinary) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.ChartBinary) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.ChartBinary.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.HistoricalChart getCurrencyChart(java.lang.String symbol, com.xignite.www.services.HistoricalPeriodTypes periodType, java.lang.String startDate, java.lang.String endDate, com.xignite.www.services.StockChartStyles style, int width, int height, java.lang.String preset) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[45]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetCurrencyChart");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCurrencyChart"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, periodType, startDate, endDate, style, new java.lang.Integer(width), new java.lang.Integer(height), preset});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.HistoricalChart) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.HistoricalChart) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.HistoricalChart.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.ChartBinary getCurrencyChartBinary(java.lang.String symbol, com.xignite.www.services.HistoricalPeriodTypes periodType, java.lang.String startDate, java.lang.String endDate, com.xignite.www.services.StockChartStyles style, int width, int height, java.lang.String preset) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[46]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetCurrencyChartBinary");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCurrencyChartBinary"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, periodType, startDate, endDate, style, new java.lang.Integer(width), new java.lang.Integer(height), preset});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.ChartBinary) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.ChartBinary) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.ChartBinary.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CurrencyChartIntraday getCurrencyIntradayChart(java.lang.String symbol, java.lang.String startTime, java.lang.String endTime, java.lang.String timeZone, com.xignite.www.services.StockChartStyles style, int width, int height, java.lang.String periodType, int tickPeriods, java.lang.String preset) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[47]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetCurrencyIntradayChart");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCurrencyIntradayChart"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, startTime, endTime, timeZone, style, new java.lang.Integer(width), new java.lang.Integer(height), periodType, new java.lang.Integer(tickPeriods), preset});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CurrencyChartIntraday) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CurrencyChartIntraday) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CurrencyChartIntraday.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.ChartBinary getCurrencyIntradayChartCustomBinary(java.lang.String symbol, java.lang.String startTime, java.lang.String endTime, java.lang.String timeZone, com.xignite.www.services.StockChartStyles style, int width, int height, java.lang.String periodType, int tickPeriods, com.xignite.www.services.ChartDesign design) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[48]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetCurrencyIntradayChartCustomBinary");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCurrencyIntradayChartCustomBinary"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, startTime, endTime, timeZone, style, new java.lang.Integer(width), new java.lang.Integer(height), periodType, new java.lang.Integer(tickPeriods), design});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.ChartBinary) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.ChartBinary) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.ChartBinary.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.CurrencyChartIntraday getCurrencyIntradayChartCustom(java.lang.String symbol, java.lang.String startTime, java.lang.String endTime, java.lang.String timeZone, com.xignite.www.services.StockChartStyles style, int width, int height, java.lang.String periodType, int tickPeriods, com.xignite.www.services.ChartDesign design) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[49]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetCurrencyIntradayChartCustom");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetCurrencyIntradayChartCustom"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, startTime, endTime, timeZone, style, new java.lang.Integer(width), new java.lang.Integer(height), periodType, new java.lang.Integer(tickPeriods), design});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.CurrencyChartIntraday) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.CurrencyChartIntraday) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.CurrencyChartIntraday.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.ChartDesign getChartDesign() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[50]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetChartDesign");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetChartDesign"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.ChartDesign) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.ChartDesign) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.ChartDesign.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.SingleTick getTick(java.lang.String symbol, java.lang.String time) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[51]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetTick");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetTick"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, time});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.SingleTick) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.SingleTick) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.SingleTick.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.Ticks getTicks(java.lang.String symbol, java.lang.String startTime, java.lang.String endTime, com.xignite.www.services.TickPeriod tickPrecision, int tickPeriods) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[52]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetTicks");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetTicks"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, startTime, endTime, tickPrecision, new java.lang.Integer(tickPeriods)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.Ticks) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.Ticks) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.Ticks.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.Ticks getHistoricalTicks(java.lang.String symbol, java.lang.String startTime, java.lang.String endTime, java.lang.String asOfDate, com.xignite.www.services.TickPeriod tickPrecision, int tickPeriods) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[53]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetHistoricalTicks");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalTicks"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, startTime, endTime, asOfDate, tickPrecision, new java.lang.Integer(tickPeriods)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.Ticks) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.Ticks) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.Ticks.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.HighLowTick getHistoricalHighLow(java.lang.String symbol, java.lang.String startDateTime, java.lang.String endDateTime) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[54]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetHistoricalHighLow");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetHistoricalHighLow"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, startDateTime, endDateTime});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.HighLowTick) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.HighLowTick) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.HighLowTick.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.xignite.www.services.HighLowTick getIntradayHighLow(java.lang.String symbol, java.lang.String startDateTime, java.lang.String endDateTime) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[55]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.xignite.com/services/GetIntradayHighLow");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "GetIntradayHighLow"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {symbol, startDateTime, endDateTime});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.xignite.www.services.HighLowTick) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.xignite.www.services.HighLowTick) org.apache.axis.utils.JavaUtils.convert(_resp, com.xignite.www.services.HighLowTick.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}

package demo1;

public class Book {

	private String title;
	private Member member;
	
	public Book() {
	}
	
	public Book(String title) {
		super();
		this.title = title;
	}

	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
		
	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public void status(){
		
		if(member == null)
			System.out.println(title+" is not issued to anyone.");
		else
			System.out.println(title+ " has issued to "+ member.getName());
	}

	public void issueBook(Member member){
		if(this.member != null)
			System.out.println("Book already issued");
		else if(member.getBook() != null)
			System.out.println("Book cannot be issued");
		else{
			
			this.member = member;
			member.setBook(this);
		}
	}
	
	public void returnBook(Member member){
		if(member.getBook() == null)
			System.out.println("Book cannot be returned as it has not been issued");
		else {
			this.member = member;
			member.setBook(null);
			System.out.println("Book is returned");
		}
	}
	
}

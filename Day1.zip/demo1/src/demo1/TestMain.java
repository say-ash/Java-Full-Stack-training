package demo1;


public class TestMain {

	public static void main(String[] args) {
	
		
		Book book = new Book("Java Book");
		Member member = new Member("Ashraf");
		
		book.status();
		member.status();
		book.returnBook(member);
		book.issueBook(member);
		book.status();
		member.status();
		book.returnBook(member);
	}
}

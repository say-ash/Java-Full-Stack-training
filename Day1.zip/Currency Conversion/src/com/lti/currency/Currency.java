package com.lti.currency;

public interface Currency {

	double dollarValue();
}

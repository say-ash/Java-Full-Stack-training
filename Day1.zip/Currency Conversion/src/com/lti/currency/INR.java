package com.lti.currency;

public class INR implements Currency{

	@Override
	public double dollarValue() {
		return 1.0;
	}

	
}

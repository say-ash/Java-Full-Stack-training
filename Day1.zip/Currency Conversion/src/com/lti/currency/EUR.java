package com.lti.currency;

public class EUR implements Currency{

	@Override
	public double dollarValue() {
		return 0.88;
	}

}

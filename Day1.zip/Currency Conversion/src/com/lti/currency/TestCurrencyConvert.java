package com.lti.currency;

public class TestCurrencyConvert {

	public static void main(String[] args) {
	
		System.out.println("Result: "+CurrencyConverter.convert(1000, new USD(), new EUR()));
		
	}

}

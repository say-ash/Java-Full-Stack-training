package com.lti.currency;

public final class CurrencyConverter {

	private CurrencyConverter(){}
	public static double convert(double amount, Currency source, Currency target){
		return target.dollarValue()/source.dollarValue()*amount;
		
	}
	

}

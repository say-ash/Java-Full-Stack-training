package com.lti.currency;

public class USD implements Currency {

	@Override
	public double dollarValue() {
		return 70.0;
	}
}

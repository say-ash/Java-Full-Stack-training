package com.classes;

public class StockSingleton {

	private static Stock lti;
	public static Stock getStock(){
		if(lti ==  null)
			lti = new Stock();
		return lti;
	}
}

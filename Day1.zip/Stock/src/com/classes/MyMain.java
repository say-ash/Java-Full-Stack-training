package com.classes;

import com.interfaces.Broker;
import com.interfaces.Exchange;
import com.interfaces.Holder;

public class MyMain {

	public static void main(String[] args) {

		Holder h = StockSingleton.getStock();
		Broker b = StockSingleton.getStock();
		Exchange e = StockSingleton.getStock();
		
		if(h==b){
			System.out.println("True");
		}	else{
			System.out.println("false");
		}
		
	}

}

package com.classes;

import com.interfaces.Exchange;

public class Stock implements Exchange {

	@Override
	public void getQoute() {
		System.out.println("Getting the qoute...");
		
	}

	@Override
	public void viewQoute() {
		
		System.out.println("Viewing the qoute...");
	}

	@Override
	public void setQoute() {
		
		System.out.println("Setting the qoute...");
		
	}

}

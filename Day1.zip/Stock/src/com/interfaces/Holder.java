package com.interfaces;

public interface Holder {

	void viewQoute();
}

package com.interfaces;

public interface Broker extends Holder {

	void getQoute();
	
}

package com.interfaces;

public interface Exchange extends Broker {

	void setQoute();
}

package com.view;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.model.Employee;
import com.service.EmployeeService;

@Component
public class EmployeeView {
	
	@Autowired
	EmployeeService employeeService;
	
	public EmployeeView() {
		System.out.println("Employee View Created");
	}
	
	public void displayOptions()
	{
		System.out.println("Please Enter Your Choice either 1 or 2");
		System.out.println("1.Add Employee");
		System.out.println("2.View Employee");
		Scanner scn= new Scanner(System.in);
		int choice= scn.nextInt();
		
		switch (choice) 
		{
		case 1:
			System.out.println("Please Enter Name");
			String name=scn.nextLine();
			System.out.println("Please Enter City");
			String city=scn.nextLine();
			Employee e = new Employee();
			e.setName(name);
			e.setCity(city);
			
			boolean result= employeeService.addEmployee(e);
			if(result)
				System.out.println("Employee Added Succesfully");
			break;

		case 2:
			List<Employee> empList= employeeService.viewEmployee();
			System.out.println(empList);
			
		default:
			break;
		}
		
		System.out.println("Do you want to View Employees");
		String option= scn.next();
		
		if("y".equalsIgnoreCase(option))
		{
			List<Employee> empList= employeeService.viewEmployee();
			System.out.println(empList);
		}
		
		
	}

}

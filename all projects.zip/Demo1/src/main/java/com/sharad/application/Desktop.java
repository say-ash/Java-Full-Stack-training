package com.sharad.application;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Desktop {
	
	@Autowired
	private TV tv;
	
	public void TvWala()
	{
		tv.tvName();
	}
	

}

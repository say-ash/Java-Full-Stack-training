package com.sharad.application;

import org.springframework.stereotype.Component;

@Component
public class Onida implements TV{

	public void tvName() {

		System.out.println("Logy Kya ONIDA");
	}

}

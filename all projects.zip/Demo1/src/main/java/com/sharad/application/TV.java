package com.sharad.application;

public interface TV {
	
	public void tvName();
	

}

package com.sharad.house;

public interface Fridge {

	public void OpenDoor();
}

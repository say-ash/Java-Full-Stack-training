package com.sharad.house;

import org.springframework.stereotype.Component;

@Component
public class Samsung implements Fridge{

	public void OpenDoor() {

		System.out.println("Mai hu Sam...Sung...");
		}

}

package com.sharad.hello;

public class Hello {
	
	private String message;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		setMyMessage(message);
	}
	private void setMyMessage(String message2) {
		this.message = message2;
		
	}
	public Hello() {
		System.out.println("Hello Constructor");

	}
	public Hello(int x) {
		System.out.println("Hello Constructor");
	}
	public void sayHello() {
		System.out.println("Hello Boss");
	}
	
	public void initBean() {
		System.out.println("bean ban gya....");
	}
	
	public void myLastWish() {
		System.out.println("Killed");
	}

}

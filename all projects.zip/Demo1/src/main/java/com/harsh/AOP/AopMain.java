package com.harsh.AOP;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class AopMain {

	public static void main(String[] args) {
		
		ApplicationContext cont= new AnnotationConfigApplicationContext(AopApp.class);
		
		Student student= cont.getBean(Student.class);
		student.setAge(10);;
		student.setName("Harsh");
		System.out.println(student);
		
		
		
	}
	
}

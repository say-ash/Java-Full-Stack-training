package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.model.Employee;

@Component
@Primary
public class EmployeeService implements EmployeeServiceInterface {

List<Employee> list=new ArrayList<Employee>();

	public boolean addEmployee(Employee e) 
	{
		//System.out.println("Add Employee service executed");
		list.add(e);
		return false;
	}

	public List<Employee> viewEmployee() 
	{
		return list;
	}

}

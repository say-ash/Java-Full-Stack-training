package com.service;

import java.util.List;

import com.model.Employee;

public interface EmployeeServiceInterface {

	boolean addEmployee(Employee e);
	List<Employee> viewEmployee();

}
package com.dao;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.view.EmployeeView;

public class EmployeeApp
{

	public static void main(String[] args) {
		
		ApplicationContext con=new AnnotationConfigApplicationContext(AppConfig.class);
		EmployeeView empView=con.getBean(EmployeeView.class);
		empView.displayOptions();
		
		
	}
}

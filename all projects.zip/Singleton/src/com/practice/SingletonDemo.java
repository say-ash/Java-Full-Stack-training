package com.practice;

import java.io.Serializable;

class X implements Serializable {

	static int x1;
	private static X x;

	private  X() {
	}

	static X getObject() {
		return x = new X();
	}
}

public class SingletonDemo {

	public static void main(String[] args) {
		X x = X.getObject();
		X.x1 = 10;
		System.out.println(X.x1);
		X.x1 = 20;
		System.out.println(X.x1);
		

	}

}

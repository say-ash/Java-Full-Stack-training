package com.lti.dao;

import java.util.List;

import com.lti.model.User;

public interface InterfaceUserDao {

	boolean saveUser(User u);
	List<User> viewUserDetails();
}

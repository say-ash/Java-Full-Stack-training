package com.lti.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lti.model.User;
import com.lti.service.InterfaceUserService;

@Controller
public class UserController {

	@Autowired
	private InterfaceUserService userService;
	
	@RequestMapping("click")
	public String home(Model model) {
		User u = new User();
		model.addAttribute(u);
		return  "home";
	}
	//@ModelAttribute("user")
	@RequestMapping(value="/register", method=RequestMethod.POST)
	public ModelAndView savData(@ModelAttribute("user") User u) {
		System.out.println(u);
		boolean b = userService.saveUser(u);
		if(b) {
			return new ModelAndView("show");
		}
		return new ModelAndView("fail");	
	}
	
	@RequestMapping("/show")
	public ModelAndView showData() {
		List<User> list = userService.viewUserDetails();
		System.out.println(list);
		return new ModelAndView("display","lst",list);
		
	}
}

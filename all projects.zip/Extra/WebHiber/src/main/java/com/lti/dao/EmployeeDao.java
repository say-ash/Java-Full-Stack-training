package com.lti.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.lti.entity.Employee;
import com.lti.entity.EmployeeAnno;
import com.lti.util.MyDataSource;

public class EmployeeDao {

	SessionFactory factory=MyDataSource.getFactory();


	public int saveEmployee(Employee employee) {
		Session session = factory.openSession();
		System.out.println(employee +"dao");
		//put employee in table
		Transaction tx = session.beginTransaction();
		
		Employee emp = employee;
		session.save(emp);
		session.remove(new Employee(1,"Ashraf","Mumbai"));
		emp.setCity("Lucknow");
		session.evict(emp);
		
		//Integer x=(Integer)session.save(employee);
		tx.commit();
		session.remove(emp);
		session.delete(emp);
		session.close();
		return 1;
	}
	
	public void getEmployee(int id) {
		Session session = factory.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		//EmployeeAnno ee = session.save(new EmployeeAnno(1,"Sharad","Lucknow"));
		
		//EmployeeAnno ee = session.get(EmployeeAnno.class, id);
		tx.commit();
	}
	
	public static void main(String[] args) {
		new EmployeeDao().getEmployee(1);
	}
}

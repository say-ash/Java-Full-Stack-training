package com.lti.entity;

import javax.persistence.*;

@Entity
@Table(name="ADDRESS")
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ADDRESS_ID" )
	private int id;
	@Column(name="ADDRES_CITY" )
	private String city;
	
	@OneToOne(fetch=FetchType.EAGER)
	@PrimaryKeyJoinColumn
}

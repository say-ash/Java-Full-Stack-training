package com.lti.main;

import com.lti.entity.Employee;
import com.lti.service.EmployeeServce;

public class EmployeeMain {
	public static void main(String[] args) {


		Employee employee = new Employee(13,"Sharad","Lucknow");
		EmployeeServce empser=new EmployeeServce();
		int res=empser.addEmployee(employee);
		if(res==1)
		{
			System.out.println("ok");
		}
		else
		{
			System.out.println("bad");
		}
	}
}

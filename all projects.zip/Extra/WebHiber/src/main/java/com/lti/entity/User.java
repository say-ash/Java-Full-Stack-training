package com.lti.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.*;
import javax.persistence.CascadeType;
import com.lti.entity.Address;

@Entity
@Table(name="USER")

public class User {
	
	@Id
	@GeneratedValue (strategy=GenerationType.AUTO)
	@Column(name="USER_ID")
	private long id;
	
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@PrimaryKeyJoinColumn
	
	private Address address;

	public User(long id, Address address) {
		super();
		this.id = id;
		this.address = address;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	


}

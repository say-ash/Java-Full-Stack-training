package com.lti.service;

import com.lti.dao.EmployeeDao;
import com.lti.entity.Employee;

public class EmployeeServce {

	public int addEmployee(Employee employee) {
		System.out.println(employee);
		employee.setCity("pune");
		EmployeeDao dao=new EmployeeDao();
		int res = dao.saveEmployee(employee);
		return 1;
	}
}

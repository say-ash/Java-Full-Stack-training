package com.lti.main;
import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.Transaction;
import com.lti.entity.Employee;
public class Hello {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Configuration conf=new Configuration();
		conf.configure();
		System.out.println("configure");
		SessionFactory factory= conf.buildSessionFactory();
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		/*
		 * System.out.println("Enter Id:"); int id=sc.nextInt();
		 * System.out.println("Enter Name:"); String name=sc.next();
		 * System.out.println("Enter City:"); String city=sc.next();
		 */
		Employee e=new Employee();
		session.save(e);
		tx.commit();
		session.close();
		factory.close();
	}
}

package com.hibernate.entity;

public class Employee {
	
private String name;
private int id;
private String city;
public Employee(int i, String string, String string2) {
	// TODO Auto-generated constructor stub
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
	
}
@Override
public String toString() {
	return "Employee [name=" + name + ", id=" + id + ", city=" + city + "]";
}

}

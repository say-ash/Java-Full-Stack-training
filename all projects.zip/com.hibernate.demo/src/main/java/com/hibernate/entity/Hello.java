package com.hibernate.entity;

import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
public class Hello {
	public static void main(String[] args) {
		
		Configuration configuration = new Configuration();
		configuration.configure();
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		org.hibernate.Transaction tx = session.beginTransaction();
		
		Employee emp = new Employee(1,"hello","mumbai");
		session.save(emp);
		tx.commit();
		session.close();
		sessionFactory.close();

	}

}

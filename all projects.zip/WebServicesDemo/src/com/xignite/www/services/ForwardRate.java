/**
 * ForwardRate.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.xignite.www.services;

public class ForwardRate  extends com.xignite.www.services.Common  implements java.io.Serializable {
    private java.lang.String symbol;

    private com.xignite.www.services.Currency from;

    private com.xignite.www.services.Currency to;

    private java.lang.String date;

    private java.lang.String time;

    private double bid;

    private java.lang.String bidTime;

    private double ask;

    private java.lang.String askTime;

    private int factor;

    private com.xignite.www.services.Forward[] forwards;

    public ForwardRate() {
    }

    public ForwardRate(
           com.xignite.www.services.OutcomeTypes outcome,
           java.lang.String message,
           java.lang.String identity,
           double delay,
           java.lang.String symbol,
           com.xignite.www.services.Currency from,
           com.xignite.www.services.Currency to,
           java.lang.String date,
           java.lang.String time,
           double bid,
           java.lang.String bidTime,
           double ask,
           java.lang.String askTime,
           int factor,
           com.xignite.www.services.Forward[] forwards) {
        super(
            outcome,
            message,
            identity,
            delay);
        this.symbol = symbol;
        this.from = from;
        this.to = to;
        this.date = date;
        this.time = time;
        this.bid = bid;
        this.bidTime = bidTime;
        this.ask = ask;
        this.askTime = askTime;
        this.factor = factor;
        this.forwards = forwards;
    }


    /**
     * Gets the symbol value for this ForwardRate.
     * 
     * @return symbol
     */
    public java.lang.String getSymbol() {
        return symbol;
    }


    /**
     * Sets the symbol value for this ForwardRate.
     * 
     * @param symbol
     */
    public void setSymbol(java.lang.String symbol) {
        this.symbol = symbol;
    }


    /**
     * Gets the from value for this ForwardRate.
     * 
     * @return from
     */
    public com.xignite.www.services.Currency getFrom() {
        return from;
    }


    /**
     * Sets the from value for this ForwardRate.
     * 
     * @param from
     */
    public void setFrom(com.xignite.www.services.Currency from) {
        this.from = from;
    }


    /**
     * Gets the to value for this ForwardRate.
     * 
     * @return to
     */
    public com.xignite.www.services.Currency getTo() {
        return to;
    }


    /**
     * Sets the to value for this ForwardRate.
     * 
     * @param to
     */
    public void setTo(com.xignite.www.services.Currency to) {
        this.to = to;
    }


    /**
     * Gets the date value for this ForwardRate.
     * 
     * @return date
     */
    public java.lang.String getDate() {
        return date;
    }


    /**
     * Sets the date value for this ForwardRate.
     * 
     * @param date
     */
    public void setDate(java.lang.String date) {
        this.date = date;
    }


    /**
     * Gets the time value for this ForwardRate.
     * 
     * @return time
     */
    public java.lang.String getTime() {
        return time;
    }


    /**
     * Sets the time value for this ForwardRate.
     * 
     * @param time
     */
    public void setTime(java.lang.String time) {
        this.time = time;
    }


    /**
     * Gets the bid value for this ForwardRate.
     * 
     * @return bid
     */
    public double getBid() {
        return bid;
    }


    /**
     * Sets the bid value for this ForwardRate.
     * 
     * @param bid
     */
    public void setBid(double bid) {
        this.bid = bid;
    }


    /**
     * Gets the bidTime value for this ForwardRate.
     * 
     * @return bidTime
     */
    public java.lang.String getBidTime() {
        return bidTime;
    }


    /**
     * Sets the bidTime value for this ForwardRate.
     * 
     * @param bidTime
     */
    public void setBidTime(java.lang.String bidTime) {
        this.bidTime = bidTime;
    }


    /**
     * Gets the ask value for this ForwardRate.
     * 
     * @return ask
     */
    public double getAsk() {
        return ask;
    }


    /**
     * Sets the ask value for this ForwardRate.
     * 
     * @param ask
     */
    public void setAsk(double ask) {
        this.ask = ask;
    }


    /**
     * Gets the askTime value for this ForwardRate.
     * 
     * @return askTime
     */
    public java.lang.String getAskTime() {
        return askTime;
    }


    /**
     * Sets the askTime value for this ForwardRate.
     * 
     * @param askTime
     */
    public void setAskTime(java.lang.String askTime) {
        this.askTime = askTime;
    }


    /**
     * Gets the factor value for this ForwardRate.
     * 
     * @return factor
     */
    public int getFactor() {
        return factor;
    }


    /**
     * Sets the factor value for this ForwardRate.
     * 
     * @param factor
     */
    public void setFactor(int factor) {
        this.factor = factor;
    }


    /**
     * Gets the forwards value for this ForwardRate.
     * 
     * @return forwards
     */
    public com.xignite.www.services.Forward[] getForwards() {
        return forwards;
    }


    /**
     * Sets the forwards value for this ForwardRate.
     * 
     * @param forwards
     */
    public void setForwards(com.xignite.www.services.Forward[] forwards) {
        this.forwards = forwards;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ForwardRate)) return false;
        ForwardRate other = (ForwardRate) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.symbol==null && other.getSymbol()==null) || 
             (this.symbol!=null &&
              this.symbol.equals(other.getSymbol()))) &&
            ((this.from==null && other.getFrom()==null) || 
             (this.from!=null &&
              this.from.equals(other.getFrom()))) &&
            ((this.to==null && other.getTo()==null) || 
             (this.to!=null &&
              this.to.equals(other.getTo()))) &&
            ((this.date==null && other.getDate()==null) || 
             (this.date!=null &&
              this.date.equals(other.getDate()))) &&
            ((this.time==null && other.getTime()==null) || 
             (this.time!=null &&
              this.time.equals(other.getTime()))) &&
            this.bid == other.getBid() &&
            ((this.bidTime==null && other.getBidTime()==null) || 
             (this.bidTime!=null &&
              this.bidTime.equals(other.getBidTime()))) &&
            this.ask == other.getAsk() &&
            ((this.askTime==null && other.getAskTime()==null) || 
             (this.askTime!=null &&
              this.askTime.equals(other.getAskTime()))) &&
            this.factor == other.getFactor() &&
            ((this.forwards==null && other.getForwards()==null) || 
             (this.forwards!=null &&
              java.util.Arrays.equals(this.forwards, other.getForwards())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getSymbol() != null) {
            _hashCode += getSymbol().hashCode();
        }
        if (getFrom() != null) {
            _hashCode += getFrom().hashCode();
        }
        if (getTo() != null) {
            _hashCode += getTo().hashCode();
        }
        if (getDate() != null) {
            _hashCode += getDate().hashCode();
        }
        if (getTime() != null) {
            _hashCode += getTime().hashCode();
        }
        _hashCode += new Double(getBid()).hashCode();
        if (getBidTime() != null) {
            _hashCode += getBidTime().hashCode();
        }
        _hashCode += new Double(getAsk()).hashCode();
        if (getAskTime() != null) {
            _hashCode += getAskTime().hashCode();
        }
        _hashCode += getFactor();
        if (getForwards() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getForwards());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getForwards(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ForwardRate.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ForwardRate"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("symbol");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("from");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "From"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Currency"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("to");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "To"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Currency"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("date");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("time");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Time"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Bid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bidTime");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "BidTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ask");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Ask"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("askTime");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "AskTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("factor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Factor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("forwards");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Forwards"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Forward"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Forward"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

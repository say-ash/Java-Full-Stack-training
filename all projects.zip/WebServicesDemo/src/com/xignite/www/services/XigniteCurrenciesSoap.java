/**
 * XigniteCurrenciesSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.xignite.www.services;

public interface XigniteCurrenciesSoap extends java.rmi.Remote {

    /**
     * List supported currencies.
     */
    public com.xignite.www.services.CurrencyList listCurrencies() throws java.rmi.RemoteException;

    /**
     * List supported currencies.
     */
    public com.xignite.www.services.CurrencyList listActiveCurrencies() throws java.rmi.RemoteException;

    /**
     * List supported official rates.
     */
    public com.xignite.www.services.OfficialRates listOfficialRates() throws java.rmi.RemoteException;

    /**
     * Get Unit Of Account.
     */
    public com.xignite.www.services.UnitOfAccount getUnitOfAccount(java.lang.String currency, java.lang.String asOfDate) throws java.rmi.RemoteException;

    /**
     * Convert value from one currency to another in real-time.
     */
    public com.xignite.www.services.ExchangeConversion convertRealTimeValue(java.lang.String from, java.lang.String to, double amount) throws java.rmi.RemoteException;

    /**
     * Convert value from one currency to another as of a historical
     * date.
     */
    public com.xignite.www.services.ExchangeConversion convertHistoricalValue(java.lang.String from, java.lang.String to, java.lang.String asOfDate, double amount) throws java.rmi.RemoteException;

    /**
     * Returns a set of real-time currency forward rates.
     */
    public com.xignite.www.services.ForwardRate getRealTimeForwardRate(java.lang.String from, java.lang.String to) throws java.rmi.RemoteException;

    /**
     * Returns a real-time currency cross-rate.
     */
    public com.xignite.www.services.CrossRate getRealTimeCrossRateAsString(java.lang.String from, java.lang.String to) throws java.rmi.RemoteException;

    /**
     * Returns the latest possible cross rate.
     */
    public com.xignite.www.services.CrossRate getLatestCrossRate(java.lang.String from, java.lang.String to) throws java.rmi.RemoteException;

    /**
     * Returns the latest possible cross rate.
     */
    public com.xignite.www.services.CrossRate[] getLatestCrossRates(java.lang.String from, java.lang.String tos) throws java.rmi.RemoteException;

    /**
     * Returns a real-time currency cross-rate.
     */
    public com.xignite.www.services.CrossRate getRealTimeCrossRate(com.xignite.www.services.Currencies from, com.xignite.www.services.Currencies to) throws java.rmi.RemoteException;

    /**
     * Returns a real-time currency cross-rate with the times in GMT.
     */
    public com.xignite.www.services.CrossRate getRealTimeCrossRateGMT(com.xignite.www.services.Currencies from, com.xignite.www.services.Currencies to) throws java.rmi.RemoteException;

    /**
     * Returns a real-time currency cross-rate.
     */
    public com.xignite.www.services.CrossRate getRawCrossRate(com.xignite.www.services.Currencies from, com.xignite.www.services.Currencies to) throws java.rmi.RemoteException;

    /**
     * Returns a real-time currency cross-rate.
     */
    public com.xignite.www.services.CrossRate[] getRawCrossRates(java.lang.String symbols) throws java.rmi.RemoteException;

    /**
     * Returns the latest possible cross rate.
     */
    public com.xignite.www.services.CrossRate[] getRealTimeCrossRates(java.lang.String symbols) throws java.rmi.RemoteException;

    /**
     * Returns historical currency cross-rate tables for a range of
     * dates.
     */
    public com.xignite.www.services.CrossRateTable[] getHistoricalCrossRateTables(java.lang.String symbols, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException;

    /**
     * Returns historical currency cross-rate tables for a range of
     * dates.
     */
    public com.xignite.www.services.CrossRateTableWithBidAsk[] getHistoricalCrossRateTablesBidAsk(java.lang.String symbols, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException;

    /**
     * Returns historical currency cross-rate tables for a range of
     * dates.
     */
    public com.xignite.www.services.Report getCurrencyReport(java.lang.String from, java.lang.String to, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException;

    /**
     * Returns a historical currency cross-rate table.
     */
    public com.xignite.www.services.CrossRateTable getHistoricalCrossRateTable(java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException;

    /**
     * Returns a historical currency cross-rate table.
     */
    public com.xignite.www.services.CrossRateTableWithBidAsk getHistoricalCrossRateTableBidAsk(java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException;

    /**
     * Returns a real-time currency cross-rate table.
     */
    public com.xignite.www.services.CrossRateTable getRealTimeCrossRateTable(java.lang.String symbols) throws java.rmi.RemoteException;

    /**
     * Returns a real-time currency cross-rate table.
     */
    public com.xignite.www.services.CrossRateTableWithBidAsk getRealTimeCrossRateTableWithBidAsk(java.lang.String symbols) throws java.rmi.RemoteException;

    /**
     * Returns all valid cross rates for a currency.
     */
    public com.xignite.www.services.CrossRateTableLineWithBidAsk getAllCrossRatesForACurrency(java.lang.String symbol) throws java.rmi.RemoteException;

    /**
     * Returns a real-time currency cross-rate table as an HTML Output.
     */
    public com.xignite.www.services.HTMLCrossRateTable getRealTimeCrossRateTableAsHTML(java.lang.String symbols, java.lang.String columnHeaderStyle, java.lang.String lineHeaderStyle, java.lang.String cellStyle) throws java.rmi.RemoteException;

    /**
     * Returns a real-time currency cross-rate table as an HTML Output.
     */
    public com.xignite.www.services.HTMLCrossRateTable getSimpleRealTimeCrossRateTableAsHTML(java.lang.String symbols, java.lang.String columnHeaderStyle, java.lang.String lineHeaderStyle, java.lang.String cellStyle) throws java.rmi.RemoteException;

    /**
     * Returns a historical currency cross-rate table as an HTML Output.
     */
    public com.xignite.www.services.HTMLCrossRateTable getHistoricalCrossRateTableAsHTML(java.lang.String symbols, java.lang.String asOfDate, java.lang.String columnHeaderStyle, java.lang.String lineHeaderStyle, java.lang.String cellStyle) throws java.rmi.RemoteException;

    /**
     * Returns a cross-rate as of a historical date.
     */
    public com.xignite.www.services.HistoricalCrossRate getHistoricalCrossRate(java.lang.String symbol, java.lang.String asOfDate) throws java.rmi.RemoteException;

    /**
     * Returns multiple cross-rates as of a historical date.
     */
    public com.xignite.www.services.HistoricalCrossRate[] getHistoricalCrossRates(java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException;

    /**
     * Returns a cross-rate with bid/ask as of a historical date.
     */
    public com.xignite.www.services.FullHistoricalCrossRate getHistoricalCrossRateBidAsk(java.lang.String symbol, java.lang.String asOfDate) throws java.rmi.RemoteException;

    /**
     * Returns multiple cross-rates with bid/ask as of a historical
     * date.
     */
    public com.xignite.www.services.FullHistoricalCrossRate[] getHistoricalCrossRatesBidAsk(java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException;

    /**
     * This operation returns a range of cross-rates for a currency
     * pair.
     */
    public com.xignite.www.services.HistoricalCrossRates getHistoricalCrossRatesRange(java.lang.String symbol, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException;

    /**
     * This operation returns a range of cross-rates for a currency
     * pair.
     */
    public com.xignite.www.services.FullHistoricalCrossRates getHistoricalCrossRatesBidAskRange(java.lang.String symbol, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException;

    /**
     * This operation returns a range of cross-rates for a currency
     * pair.
     */
    public com.xignite.www.services.HistoricalCrossRates getHistoricalCrossRatesAsOf(java.lang.String symbol, java.util.Calendar endDate, com.xignite.www.services.PeriodTypes periodType, int periods) throws java.rmi.RemoteException;

    /**
     * This operation returns a range of cross-rates for a currency
     * pair.
     */
    public com.xignite.www.services.FullHistoricalCrossRates getHistoricalCrossRatesBidAskAsOf(java.lang.String symbol, java.util.Calendar endDate, com.xignite.www.services.PeriodTypes periodType, int periods) throws java.rmi.RemoteException;

    /**
     * Returns an official cross-rate as of a historical date.
     */
    public com.xignite.www.services.HistoricalCrossRate getOfficialCrossRate(com.xignite.www.services.CountryTypes countryType, com.xignite.www.services.Currencies symbol, java.lang.String asOfDate) throws java.rmi.RemoteException;

    /**
     * Returns an official cross-rate as of a historical date.
     */
    public com.xignite.www.services.HistoricalCrossRate[] getOfficialCrossRates(com.xignite.www.services.CountryTypes countryType, java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException;

    /**
     * Returns an official cross-rate as of a historical date.
     */
    public com.xignite.www.services.FullHistoricalCrossRate getOfficialCrossRateBidAsk(com.xignite.www.services.CountryTypes countryType, com.xignite.www.services.Currencies symbol, java.lang.String asOfDate) throws java.rmi.RemoteException;

    /**
     * Returns an official cross-rate as of a historical date.
     */
    public com.xignite.www.services.FullHistoricalCrossRate[] getOfficialCrossRatesBidAsk(com.xignite.www.services.CountryTypes countryType, java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException;

    /**
     * Returns multiple cross-rates as of a historical date.
     */
    public com.xignite.www.services.MultipleHistoricalCrossRates getMutipleHistoricalCrossRates(java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException;

    /**
     * This operation returns an array average daily historical cross-rates
     * for a period.
     */
    public com.xignite.www.services.AverageHistoricalCrossRate[] getAverageHistoricalCrossRates(java.lang.String symbols, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException;

    /**
     * This operation returns an average daily historical cross-rates
     * for a period.
     */
    public com.xignite.www.services.AverageHistoricalCrossRate getAverageHistoricalCrossRate(java.lang.String symbol, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException;

    /**
     * This operation returns a complete range of stock quotes for
     * a currency pair.
     */
    public com.xignite.www.services.FullHistoricalCrossRates getHistoricalMonthlyCrossRatesRange(java.lang.String symbol, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException;

    /**
     * This operation returns the changes in a cross-rates over the
     * last 6 months.
     */
    public com.xignite.www.services.CrossRateChange getCrossRateChange(java.lang.String symbol) throws java.rmi.RemoteException;

    /**
     * Draw a custom currency chart for a date range.
     */
    public com.xignite.www.services.HistoricalChart getCurrencyChartCustom(java.lang.String symbol, com.xignite.www.services.HistoricalPeriodTypes periodType, java.lang.String startDate, java.lang.String endDate, com.xignite.www.services.StockChartStyles style, int width, int height, com.xignite.www.services.ChartDesign design) throws java.rmi.RemoteException;

    /**
     * Draw a custom currency chart for a date range.
     */
    public com.xignite.www.services.ChartBinary getCurrencyChartCustomBinary(java.lang.String symbol, com.xignite.www.services.HistoricalPeriodTypes periodType, java.lang.String startDate, java.lang.String endDate, com.xignite.www.services.StockChartStyles style, int width, int height, com.xignite.www.services.ChartDesign design) throws java.rmi.RemoteException;

    /**
     * Draw a historical currency chart for a date range.
     */
    public com.xignite.www.services.HistoricalChart getCurrencyChart(java.lang.String symbol, com.xignite.www.services.HistoricalPeriodTypes periodType, java.lang.String startDate, java.lang.String endDate, com.xignite.www.services.StockChartStyles style, int width, int height, java.lang.String preset) throws java.rmi.RemoteException;

    /**
     * Draw a historical currency chart for a date range in binary
     * format.
     */
    public com.xignite.www.services.ChartBinary getCurrencyChartBinary(java.lang.String symbol, com.xignite.www.services.HistoricalPeriodTypes periodType, java.lang.String startDate, java.lang.String endDate, com.xignite.www.services.StockChartStyles style, int width, int height, java.lang.String preset) throws java.rmi.RemoteException;

    /**
     * Draw a intraday currency chart for a time range
     */
    public com.xignite.www.services.CurrencyChartIntraday getCurrencyIntradayChart(java.lang.String symbol, java.lang.String startTime, java.lang.String endTime, java.lang.String timeZone, com.xignite.www.services.StockChartStyles style, int width, int height, java.lang.String periodType, int tickPeriods, java.lang.String preset) throws java.rmi.RemoteException;

    /**
     * Draw a intraday currency chart for a time range in a binary
     * format
     */
    public com.xignite.www.services.ChartBinary getCurrencyIntradayChartCustomBinary(java.lang.String symbol, java.lang.String startTime, java.lang.String endTime, java.lang.String timeZone, com.xignite.www.services.StockChartStyles style, int width, int height, java.lang.String periodType, int tickPeriods, com.xignite.www.services.ChartDesign design) throws java.rmi.RemoteException;

    /**
     * Draw a intraday currency chart for a time range in a binary
     * format
     */
    public com.xignite.www.services.CurrencyChartIntraday getCurrencyIntradayChartCustom(java.lang.String symbol, java.lang.String startTime, java.lang.String endTime, java.lang.String timeZone, com.xignite.www.services.StockChartStyles style, int width, int height, java.lang.String periodType, int tickPeriods, com.xignite.www.services.ChartDesign design) throws java.rmi.RemoteException;

    /**
     * Returns the default design class for the currency Chart.
     */
    public com.xignite.www.services.ChartDesign getChartDesign() throws java.rmi.RemoteException;

    /**
     * Returns a tick for a currency pair as of a specific time in
     * the day.
     */
    public com.xignite.www.services.SingleTick getTick(java.lang.String symbol, java.lang.String time) throws java.rmi.RemoteException;

    /**
     * Returns a range of ticks for a currency pair.
     */
    public com.xignite.www.services.Ticks getTicks(java.lang.String symbol, java.lang.String startTime, java.lang.String endTime, com.xignite.www.services.TickPeriod tickPrecision, int tickPeriods) throws java.rmi.RemoteException;

    /**
     * Returns a range of ticks for a currency pair.
     */
    public com.xignite.www.services.Ticks getHistoricalTicks(java.lang.String symbol, java.lang.String startTime, java.lang.String endTime, java.lang.String asOfDate, com.xignite.www.services.TickPeriod tickPrecision, int tickPeriods) throws java.rmi.RemoteException;

    /**
     * Returns the high and the low ticks for a historical time range.
     */
    public com.xignite.www.services.HighLowTick getHistoricalHighLow(java.lang.String symbol, java.lang.String startDateTime, java.lang.String endDateTime) throws java.rmi.RemoteException;

    /**
     * Returns the high and the low ticks for today.
     */
    public com.xignite.www.services.HighLowTick getIntradayHighLow(java.lang.String symbol, java.lang.String startDateTime, java.lang.String endDateTime) throws java.rmi.RemoteException;
}

/**
 * FullHistoricalCrossRates.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.xignite.www.services;

public class FullHistoricalCrossRates  extends com.xignite.www.services.Common  implements java.io.Serializable {
    private java.lang.String symbol;

    private com.xignite.www.services.Currency from;

    private com.xignite.www.services.Currency to;

    private java.lang.String startDate;

    private java.lang.String endDate;

    private com.xignite.www.services.FullCrossRateItem[] crossRates;

    public FullHistoricalCrossRates() {
    }

    public FullHistoricalCrossRates(
           com.xignite.www.services.OutcomeTypes outcome,
           java.lang.String message,
           java.lang.String identity,
           double delay,
           java.lang.String symbol,
           com.xignite.www.services.Currency from,
           com.xignite.www.services.Currency to,
           java.lang.String startDate,
           java.lang.String endDate,
           com.xignite.www.services.FullCrossRateItem[] crossRates) {
        super(
            outcome,
            message,
            identity,
            delay);
        this.symbol = symbol;
        this.from = from;
        this.to = to;
        this.startDate = startDate;
        this.endDate = endDate;
        this.crossRates = crossRates;
    }


    /**
     * Gets the symbol value for this FullHistoricalCrossRates.
     * 
     * @return symbol
     */
    public java.lang.String getSymbol() {
        return symbol;
    }


    /**
     * Sets the symbol value for this FullHistoricalCrossRates.
     * 
     * @param symbol
     */
    public void setSymbol(java.lang.String symbol) {
        this.symbol = symbol;
    }


    /**
     * Gets the from value for this FullHistoricalCrossRates.
     * 
     * @return from
     */
    public com.xignite.www.services.Currency getFrom() {
        return from;
    }


    /**
     * Sets the from value for this FullHistoricalCrossRates.
     * 
     * @param from
     */
    public void setFrom(com.xignite.www.services.Currency from) {
        this.from = from;
    }


    /**
     * Gets the to value for this FullHistoricalCrossRates.
     * 
     * @return to
     */
    public com.xignite.www.services.Currency getTo() {
        return to;
    }


    /**
     * Sets the to value for this FullHistoricalCrossRates.
     * 
     * @param to
     */
    public void setTo(com.xignite.www.services.Currency to) {
        this.to = to;
    }


    /**
     * Gets the startDate value for this FullHistoricalCrossRates.
     * 
     * @return startDate
     */
    public java.lang.String getStartDate() {
        return startDate;
    }


    /**
     * Sets the startDate value for this FullHistoricalCrossRates.
     * 
     * @param startDate
     */
    public void setStartDate(java.lang.String startDate) {
        this.startDate = startDate;
    }


    /**
     * Gets the endDate value for this FullHistoricalCrossRates.
     * 
     * @return endDate
     */
    public java.lang.String getEndDate() {
        return endDate;
    }


    /**
     * Sets the endDate value for this FullHistoricalCrossRates.
     * 
     * @param endDate
     */
    public void setEndDate(java.lang.String endDate) {
        this.endDate = endDate;
    }


    /**
     * Gets the crossRates value for this FullHistoricalCrossRates.
     * 
     * @return crossRates
     */
    public com.xignite.www.services.FullCrossRateItem[] getCrossRates() {
        return crossRates;
    }


    /**
     * Sets the crossRates value for this FullHistoricalCrossRates.
     * 
     * @param crossRates
     */
    public void setCrossRates(com.xignite.www.services.FullCrossRateItem[] crossRates) {
        this.crossRates = crossRates;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof FullHistoricalCrossRates)) return false;
        FullHistoricalCrossRates other = (FullHistoricalCrossRates) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.symbol==null && other.getSymbol()==null) || 
             (this.symbol!=null &&
              this.symbol.equals(other.getSymbol()))) &&
            ((this.from==null && other.getFrom()==null) || 
             (this.from!=null &&
              this.from.equals(other.getFrom()))) &&
            ((this.to==null && other.getTo()==null) || 
             (this.to!=null &&
              this.to.equals(other.getTo()))) &&
            ((this.startDate==null && other.getStartDate()==null) || 
             (this.startDate!=null &&
              this.startDate.equals(other.getStartDate()))) &&
            ((this.endDate==null && other.getEndDate()==null) || 
             (this.endDate!=null &&
              this.endDate.equals(other.getEndDate()))) &&
            ((this.crossRates==null && other.getCrossRates()==null) || 
             (this.crossRates!=null &&
              java.util.Arrays.equals(this.crossRates, other.getCrossRates())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getSymbol() != null) {
            _hashCode += getSymbol().hashCode();
        }
        if (getFrom() != null) {
            _hashCode += getFrom().hashCode();
        }
        if (getTo() != null) {
            _hashCode += getTo().hashCode();
        }
        if (getStartDate() != null) {
            _hashCode += getStartDate().hashCode();
        }
        if (getEndDate() != null) {
            _hashCode += getEndDate().hashCode();
        }
        if (getCrossRates() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCrossRates());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCrossRates(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(FullHistoricalCrossRates.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "FullHistoricalCrossRates"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("symbol");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("from");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "From"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Currency"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("to");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "To"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Currency"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "StartDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("endDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "EndDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("crossRates");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CrossRates"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "FullCrossRateItem"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "FullCrossRateItem"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

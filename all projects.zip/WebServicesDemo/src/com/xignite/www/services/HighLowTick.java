/**
 * HighLowTick.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.xignite.www.services;

public class HighLowTick  extends com.xignite.www.services.Common  implements java.io.Serializable {
    private java.lang.String symbol;

    private com.xignite.www.services.HighLowTickTypes type;

    private com.xignite.www.services.SingleTick high;

    private com.xignite.www.services.SingleTick low;

    public HighLowTick() {
    }

    public HighLowTick(
           com.xignite.www.services.OutcomeTypes outcome,
           java.lang.String message,
           java.lang.String identity,
           double delay,
           java.lang.String symbol,
           com.xignite.www.services.HighLowTickTypes type,
           com.xignite.www.services.SingleTick high,
           com.xignite.www.services.SingleTick low) {
        super(
            outcome,
            message,
            identity,
            delay);
        this.symbol = symbol;
        this.type = type;
        this.high = high;
        this.low = low;
    }


    /**
     * Gets the symbol value for this HighLowTick.
     * 
     * @return symbol
     */
    public java.lang.String getSymbol() {
        return symbol;
    }


    /**
     * Sets the symbol value for this HighLowTick.
     * 
     * @param symbol
     */
    public void setSymbol(java.lang.String symbol) {
        this.symbol = symbol;
    }


    /**
     * Gets the type value for this HighLowTick.
     * 
     * @return type
     */
    public com.xignite.www.services.HighLowTickTypes getType() {
        return type;
    }


    /**
     * Sets the type value for this HighLowTick.
     * 
     * @param type
     */
    public void setType(com.xignite.www.services.HighLowTickTypes type) {
        this.type = type;
    }


    /**
     * Gets the high value for this HighLowTick.
     * 
     * @return high
     */
    public com.xignite.www.services.SingleTick getHigh() {
        return high;
    }


    /**
     * Sets the high value for this HighLowTick.
     * 
     * @param high
     */
    public void setHigh(com.xignite.www.services.SingleTick high) {
        this.high = high;
    }


    /**
     * Gets the low value for this HighLowTick.
     * 
     * @return low
     */
    public com.xignite.www.services.SingleTick getLow() {
        return low;
    }


    /**
     * Sets the low value for this HighLowTick.
     * 
     * @param low
     */
    public void setLow(com.xignite.www.services.SingleTick low) {
        this.low = low;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HighLowTick)) return false;
        HighLowTick other = (HighLowTick) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.symbol==null && other.getSymbol()==null) || 
             (this.symbol!=null &&
              this.symbol.equals(other.getSymbol()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType()))) &&
            ((this.high==null && other.getHigh()==null) || 
             (this.high!=null &&
              this.high.equals(other.getHigh()))) &&
            ((this.low==null && other.getLow()==null) || 
             (this.low!=null &&
              this.low.equals(other.getLow())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getSymbol() != null) {
            _hashCode += getSymbol().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        if (getHigh() != null) {
            _hashCode += getHigh().hashCode();
        }
        if (getLow() != null) {
            _hashCode += getLow().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HighLowTick.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HighLowTick"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("symbol");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Symbol"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "HighLowTickTypes"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("high");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "High"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "SingleTick"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("low");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Low"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "SingleTick"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

/**
 * Change.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.xignite.www.services;

public class Change  extends com.xignite.www.services.Common  implements java.io.Serializable {
    private com.xignite.www.services.ChangeTypes type;

    private double rate;

    private double change;

    private double percentChange;

    public Change() {
    }

    public Change(
           com.xignite.www.services.OutcomeTypes outcome,
           java.lang.String message,
           java.lang.String identity,
           double delay,
           com.xignite.www.services.ChangeTypes type,
           double rate,
           double change,
           double percentChange) {
        super(
            outcome,
            message,
            identity,
            delay);
        this.type = type;
        this.rate = rate;
        this.change = change;
        this.percentChange = percentChange;
    }


    /**
     * Gets the type value for this Change.
     * 
     * @return type
     */
    public com.xignite.www.services.ChangeTypes getType() {
        return type;
    }


    /**
     * Sets the type value for this Change.
     * 
     * @param type
     */
    public void setType(com.xignite.www.services.ChangeTypes type) {
        this.type = type;
    }


    /**
     * Gets the rate value for this Change.
     * 
     * @return rate
     */
    public double getRate() {
        return rate;
    }


    /**
     * Sets the rate value for this Change.
     * 
     * @param rate
     */
    public void setRate(double rate) {
        this.rate = rate;
    }


    /**
     * Gets the change value for this Change.
     * 
     * @return change
     */
    public double getChange() {
        return change;
    }


    /**
     * Sets the change value for this Change.
     * 
     * @param change
     */
    public void setChange(double change) {
        this.change = change;
    }


    /**
     * Gets the percentChange value for this Change.
     * 
     * @return percentChange
     */
    public double getPercentChange() {
        return percentChange;
    }


    /**
     * Sets the percentChange value for this Change.
     * 
     * @param percentChange
     */
    public void setPercentChange(double percentChange) {
        this.percentChange = percentChange;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Change)) return false;
        Change other = (Change) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType()))) &&
            this.rate == other.getRate() &&
            this.change == other.getChange() &&
            this.percentChange == other.getPercentChange();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        _hashCode += new Double(getRate()).hashCode();
        _hashCode += new Double(getChange()).hashCode();
        _hashCode += new Double(getPercentChange()).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Change.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Change"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ChangeTypes"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Rate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("change");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Change"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentChange");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "PercentChange"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

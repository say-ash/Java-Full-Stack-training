/**
 * CountryTypes.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.xignite.www.services;

public class CountryTypes implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected CountryTypes(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _Mexico = "Mexico";
    public static final java.lang.String _UnitedStatesAM = "UnitedStatesAM";
    public static final java.lang.String _UnitedStatesPM = "UnitedStatesPM";
    public static final java.lang.String _Canada = "Canada";
    public static final java.lang.String _Europe = "Europe";
    public static final java.lang.String _Russia = "Russia";
    public static final java.lang.String _Poland = "Poland";
    public static final java.lang.String _Romania = "Romania";
    public static final java.lang.String _Hungary = "Hungary";
    public static final java.lang.String _Chile = "Chile";
    public static final java.lang.String _Czech = "Czech";
    public static final java.lang.String _Australia = "Australia";
    public static final java.lang.String _Brazil = "Brazil";
    public static final java.lang.String _Bulgaria = "Bulgaria";
    public static final java.lang.String _China = "China";
    public static final java.lang.String _Uruguay = "Uruguay";
    public static final java.lang.String _UnitedStates = "UnitedStates";
    public static final java.lang.String _Colombia = "Colombia";
    public static final java.lang.String _Argentina = "Argentina";
    public static final java.lang.String _MexicoDoF = "MexicoDoF";
    public static final java.lang.String _Serbia = "Serbia";
    public static final java.lang.String _Macedonia = "Macedonia";
    public static final java.lang.String _Turkey = "Turkey";
    public static final java.lang.String _India = "India";
    public static final java.lang.String _Philippines = "Philippines";
    public static final java.lang.String _EuropeItalyEUR = "EuropeItalyEUR";
    public static final java.lang.String _Thailand = "Thailand";
    public static final java.lang.String _EuropeItalyUSD = "EuropeItalyUSD";
    public static final java.lang.String _UnitedArabEmirates = "UnitedArabEmirates";
    public static final java.lang.String _Kazakhstan = "Kazakhstan";
    public static final CountryTypes Mexico = new CountryTypes(_Mexico);
    public static final CountryTypes UnitedStatesAM = new CountryTypes(_UnitedStatesAM);
    public static final CountryTypes UnitedStatesPM = new CountryTypes(_UnitedStatesPM);
    public static final CountryTypes Canada = new CountryTypes(_Canada);
    public static final CountryTypes Europe = new CountryTypes(_Europe);
    public static final CountryTypes Russia = new CountryTypes(_Russia);
    public static final CountryTypes Poland = new CountryTypes(_Poland);
    public static final CountryTypes Romania = new CountryTypes(_Romania);
    public static final CountryTypes Hungary = new CountryTypes(_Hungary);
    public static final CountryTypes Chile = new CountryTypes(_Chile);
    public static final CountryTypes Czech = new CountryTypes(_Czech);
    public static final CountryTypes Australia = new CountryTypes(_Australia);
    public static final CountryTypes Brazil = new CountryTypes(_Brazil);
    public static final CountryTypes Bulgaria = new CountryTypes(_Bulgaria);
    public static final CountryTypes China = new CountryTypes(_China);
    public static final CountryTypes Uruguay = new CountryTypes(_Uruguay);
    public static final CountryTypes UnitedStates = new CountryTypes(_UnitedStates);
    public static final CountryTypes Colombia = new CountryTypes(_Colombia);
    public static final CountryTypes Argentina = new CountryTypes(_Argentina);
    public static final CountryTypes MexicoDoF = new CountryTypes(_MexicoDoF);
    public static final CountryTypes Serbia = new CountryTypes(_Serbia);
    public static final CountryTypes Macedonia = new CountryTypes(_Macedonia);
    public static final CountryTypes Turkey = new CountryTypes(_Turkey);
    public static final CountryTypes India = new CountryTypes(_India);
    public static final CountryTypes Philippines = new CountryTypes(_Philippines);
    public static final CountryTypes EuropeItalyEUR = new CountryTypes(_EuropeItalyEUR);
    public static final CountryTypes Thailand = new CountryTypes(_Thailand);
    public static final CountryTypes EuropeItalyUSD = new CountryTypes(_EuropeItalyUSD);
    public static final CountryTypes UnitedArabEmirates = new CountryTypes(_UnitedArabEmirates);
    public static final CountryTypes Kazakhstan = new CountryTypes(_Kazakhstan);
    public java.lang.String getValue() { return _value_;}
    public static CountryTypes fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        CountryTypes enumeration = (CountryTypes)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static CountryTypes fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CountryTypes.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "CountryTypes"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}

/**
 * ForwardTypes.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.xignite.www.services;

public class ForwardTypes implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected ForwardTypes(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _Overnight = "Overnight";
    public static final java.lang.String _TomorrowNext = "TomorrowNext";
    public static final java.lang.String _SpotNext = "SpotNext";
    public static final java.lang.String _OneWeek = "OneWeek";
    public static final java.lang.String _TwoWeek = "TwoWeek";
    public static final java.lang.String _ThreeWeek = "ThreeWeek";
    public static final java.lang.String _OneMonth = "OneMonth";
    public static final java.lang.String _TwoMonth = "TwoMonth";
    public static final java.lang.String _ThreeMonth = "ThreeMonth";
    public static final java.lang.String _FourMonth = "FourMonth";
    public static final java.lang.String _FiveMonth = "FiveMonth";
    public static final java.lang.String _SixMonth = "SixMonth";
    public static final java.lang.String _SevenMonth = "SevenMonth";
    public static final java.lang.String _EightMonth = "EightMonth";
    public static final java.lang.String _NineMonth = "NineMonth";
    public static final java.lang.String _TenMonth = "TenMonth";
    public static final java.lang.String _ElevenMonth = "ElevenMonth";
    public static final java.lang.String _OneYear = "OneYear";
    public static final java.lang.String _TwoYear = "TwoYear";
    public static final java.lang.String _ThreeYear = "ThreeYear";
    public static final java.lang.String _FourYear = "FourYear";
    public static final java.lang.String _FiveYear = "FiveYear";
    public static final java.lang.String _SixYear = "SixYear";
    public static final java.lang.String _SevenYear = "SevenYear";
    public static final java.lang.String _TenYear = "TenYear";
    public static final ForwardTypes Overnight = new ForwardTypes(_Overnight);
    public static final ForwardTypes TomorrowNext = new ForwardTypes(_TomorrowNext);
    public static final ForwardTypes SpotNext = new ForwardTypes(_SpotNext);
    public static final ForwardTypes OneWeek = new ForwardTypes(_OneWeek);
    public static final ForwardTypes TwoWeek = new ForwardTypes(_TwoWeek);
    public static final ForwardTypes ThreeWeek = new ForwardTypes(_ThreeWeek);
    public static final ForwardTypes OneMonth = new ForwardTypes(_OneMonth);
    public static final ForwardTypes TwoMonth = new ForwardTypes(_TwoMonth);
    public static final ForwardTypes ThreeMonth = new ForwardTypes(_ThreeMonth);
    public static final ForwardTypes FourMonth = new ForwardTypes(_FourMonth);
    public static final ForwardTypes FiveMonth = new ForwardTypes(_FiveMonth);
    public static final ForwardTypes SixMonth = new ForwardTypes(_SixMonth);
    public static final ForwardTypes SevenMonth = new ForwardTypes(_SevenMonth);
    public static final ForwardTypes EightMonth = new ForwardTypes(_EightMonth);
    public static final ForwardTypes NineMonth = new ForwardTypes(_NineMonth);
    public static final ForwardTypes TenMonth = new ForwardTypes(_TenMonth);
    public static final ForwardTypes ElevenMonth = new ForwardTypes(_ElevenMonth);
    public static final ForwardTypes OneYear = new ForwardTypes(_OneYear);
    public static final ForwardTypes TwoYear = new ForwardTypes(_TwoYear);
    public static final ForwardTypes ThreeYear = new ForwardTypes(_ThreeYear);
    public static final ForwardTypes FourYear = new ForwardTypes(_FourYear);
    public static final ForwardTypes FiveYear = new ForwardTypes(_FiveYear);
    public static final ForwardTypes SixYear = new ForwardTypes(_SixYear);
    public static final ForwardTypes SevenYear = new ForwardTypes(_SevenYear);
    public static final ForwardTypes TenYear = new ForwardTypes(_TenYear);
    public java.lang.String getValue() { return _value_;}
    public static ForwardTypes fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        ForwardTypes enumeration = (ForwardTypes)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static ForwardTypes fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ForwardTypes.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "ForwardTypes"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}

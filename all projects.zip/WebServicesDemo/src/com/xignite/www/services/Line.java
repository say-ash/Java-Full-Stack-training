/**
 * Line.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.xignite.www.services;

public class Line  implements java.io.Serializable {
    private com.xignite.www.services.LineTypes lineType;

    private java.lang.String from;

    private java.lang.String value1;

    private java.lang.String value2;

    private java.lang.String value3;

    private java.lang.String value4;

    private java.lang.String value5;

    private java.lang.String value6;

    private java.lang.String value7;

    private java.lang.String value8;

    private java.lang.String value9;

    private java.lang.String value10;

    private java.lang.String value11;

    private java.lang.String value12;

    private java.lang.String value13;

    private java.lang.String value14;

    private java.lang.String value15;

    private java.lang.String value16;

    private java.lang.String value17;

    private java.lang.String value18;

    private java.lang.String value19;

    private java.lang.String value20;

    private java.lang.String value21;

    private java.lang.String value22;

    private java.lang.String value23;

    private java.lang.String value24;

    private java.lang.String value25;

    private java.lang.String value26;

    private java.lang.String value27;

    private java.lang.String value28;

    private java.lang.String value29;

    private java.lang.String value30;

    private java.lang.String value31;

    public Line() {
    }

    public Line(
           com.xignite.www.services.LineTypes lineType,
           java.lang.String from,
           java.lang.String value1,
           java.lang.String value2,
           java.lang.String value3,
           java.lang.String value4,
           java.lang.String value5,
           java.lang.String value6,
           java.lang.String value7,
           java.lang.String value8,
           java.lang.String value9,
           java.lang.String value10,
           java.lang.String value11,
           java.lang.String value12,
           java.lang.String value13,
           java.lang.String value14,
           java.lang.String value15,
           java.lang.String value16,
           java.lang.String value17,
           java.lang.String value18,
           java.lang.String value19,
           java.lang.String value20,
           java.lang.String value21,
           java.lang.String value22,
           java.lang.String value23,
           java.lang.String value24,
           java.lang.String value25,
           java.lang.String value26,
           java.lang.String value27,
           java.lang.String value28,
           java.lang.String value29,
           java.lang.String value30,
           java.lang.String value31) {
           this.lineType = lineType;
           this.from = from;
           this.value1 = value1;
           this.value2 = value2;
           this.value3 = value3;
           this.value4 = value4;
           this.value5 = value5;
           this.value6 = value6;
           this.value7 = value7;
           this.value8 = value8;
           this.value9 = value9;
           this.value10 = value10;
           this.value11 = value11;
           this.value12 = value12;
           this.value13 = value13;
           this.value14 = value14;
           this.value15 = value15;
           this.value16 = value16;
           this.value17 = value17;
           this.value18 = value18;
           this.value19 = value19;
           this.value20 = value20;
           this.value21 = value21;
           this.value22 = value22;
           this.value23 = value23;
           this.value24 = value24;
           this.value25 = value25;
           this.value26 = value26;
           this.value27 = value27;
           this.value28 = value28;
           this.value29 = value29;
           this.value30 = value30;
           this.value31 = value31;
    }


    /**
     * Gets the lineType value for this Line.
     * 
     * @return lineType
     */
    public com.xignite.www.services.LineTypes getLineType() {
        return lineType;
    }


    /**
     * Sets the lineType value for this Line.
     * 
     * @param lineType
     */
    public void setLineType(com.xignite.www.services.LineTypes lineType) {
        this.lineType = lineType;
    }


    /**
     * Gets the from value for this Line.
     * 
     * @return from
     */
    public java.lang.String getFrom() {
        return from;
    }


    /**
     * Sets the from value for this Line.
     * 
     * @param from
     */
    public void setFrom(java.lang.String from) {
        this.from = from;
    }


    /**
     * Gets the value1 value for this Line.
     * 
     * @return value1
     */
    public java.lang.String getValue1() {
        return value1;
    }


    /**
     * Sets the value1 value for this Line.
     * 
     * @param value1
     */
    public void setValue1(java.lang.String value1) {
        this.value1 = value1;
    }


    /**
     * Gets the value2 value for this Line.
     * 
     * @return value2
     */
    public java.lang.String getValue2() {
        return value2;
    }


    /**
     * Sets the value2 value for this Line.
     * 
     * @param value2
     */
    public void setValue2(java.lang.String value2) {
        this.value2 = value2;
    }


    /**
     * Gets the value3 value for this Line.
     * 
     * @return value3
     */
    public java.lang.String getValue3() {
        return value3;
    }


    /**
     * Sets the value3 value for this Line.
     * 
     * @param value3
     */
    public void setValue3(java.lang.String value3) {
        this.value3 = value3;
    }


    /**
     * Gets the value4 value for this Line.
     * 
     * @return value4
     */
    public java.lang.String getValue4() {
        return value4;
    }


    /**
     * Sets the value4 value for this Line.
     * 
     * @param value4
     */
    public void setValue4(java.lang.String value4) {
        this.value4 = value4;
    }


    /**
     * Gets the value5 value for this Line.
     * 
     * @return value5
     */
    public java.lang.String getValue5() {
        return value5;
    }


    /**
     * Sets the value5 value for this Line.
     * 
     * @param value5
     */
    public void setValue5(java.lang.String value5) {
        this.value5 = value5;
    }


    /**
     * Gets the value6 value for this Line.
     * 
     * @return value6
     */
    public java.lang.String getValue6() {
        return value6;
    }


    /**
     * Sets the value6 value for this Line.
     * 
     * @param value6
     */
    public void setValue6(java.lang.String value6) {
        this.value6 = value6;
    }


    /**
     * Gets the value7 value for this Line.
     * 
     * @return value7
     */
    public java.lang.String getValue7() {
        return value7;
    }


    /**
     * Sets the value7 value for this Line.
     * 
     * @param value7
     */
    public void setValue7(java.lang.String value7) {
        this.value7 = value7;
    }


    /**
     * Gets the value8 value for this Line.
     * 
     * @return value8
     */
    public java.lang.String getValue8() {
        return value8;
    }


    /**
     * Sets the value8 value for this Line.
     * 
     * @param value8
     */
    public void setValue8(java.lang.String value8) {
        this.value8 = value8;
    }


    /**
     * Gets the value9 value for this Line.
     * 
     * @return value9
     */
    public java.lang.String getValue9() {
        return value9;
    }


    /**
     * Sets the value9 value for this Line.
     * 
     * @param value9
     */
    public void setValue9(java.lang.String value9) {
        this.value9 = value9;
    }


    /**
     * Gets the value10 value for this Line.
     * 
     * @return value10
     */
    public java.lang.String getValue10() {
        return value10;
    }


    /**
     * Sets the value10 value for this Line.
     * 
     * @param value10
     */
    public void setValue10(java.lang.String value10) {
        this.value10 = value10;
    }


    /**
     * Gets the value11 value for this Line.
     * 
     * @return value11
     */
    public java.lang.String getValue11() {
        return value11;
    }


    /**
     * Sets the value11 value for this Line.
     * 
     * @param value11
     */
    public void setValue11(java.lang.String value11) {
        this.value11 = value11;
    }


    /**
     * Gets the value12 value for this Line.
     * 
     * @return value12
     */
    public java.lang.String getValue12() {
        return value12;
    }


    /**
     * Sets the value12 value for this Line.
     * 
     * @param value12
     */
    public void setValue12(java.lang.String value12) {
        this.value12 = value12;
    }


    /**
     * Gets the value13 value for this Line.
     * 
     * @return value13
     */
    public java.lang.String getValue13() {
        return value13;
    }


    /**
     * Sets the value13 value for this Line.
     * 
     * @param value13
     */
    public void setValue13(java.lang.String value13) {
        this.value13 = value13;
    }


    /**
     * Gets the value14 value for this Line.
     * 
     * @return value14
     */
    public java.lang.String getValue14() {
        return value14;
    }


    /**
     * Sets the value14 value for this Line.
     * 
     * @param value14
     */
    public void setValue14(java.lang.String value14) {
        this.value14 = value14;
    }


    /**
     * Gets the value15 value for this Line.
     * 
     * @return value15
     */
    public java.lang.String getValue15() {
        return value15;
    }


    /**
     * Sets the value15 value for this Line.
     * 
     * @param value15
     */
    public void setValue15(java.lang.String value15) {
        this.value15 = value15;
    }


    /**
     * Gets the value16 value for this Line.
     * 
     * @return value16
     */
    public java.lang.String getValue16() {
        return value16;
    }


    /**
     * Sets the value16 value for this Line.
     * 
     * @param value16
     */
    public void setValue16(java.lang.String value16) {
        this.value16 = value16;
    }


    /**
     * Gets the value17 value for this Line.
     * 
     * @return value17
     */
    public java.lang.String getValue17() {
        return value17;
    }


    /**
     * Sets the value17 value for this Line.
     * 
     * @param value17
     */
    public void setValue17(java.lang.String value17) {
        this.value17 = value17;
    }


    /**
     * Gets the value18 value for this Line.
     * 
     * @return value18
     */
    public java.lang.String getValue18() {
        return value18;
    }


    /**
     * Sets the value18 value for this Line.
     * 
     * @param value18
     */
    public void setValue18(java.lang.String value18) {
        this.value18 = value18;
    }


    /**
     * Gets the value19 value for this Line.
     * 
     * @return value19
     */
    public java.lang.String getValue19() {
        return value19;
    }


    /**
     * Sets the value19 value for this Line.
     * 
     * @param value19
     */
    public void setValue19(java.lang.String value19) {
        this.value19 = value19;
    }


    /**
     * Gets the value20 value for this Line.
     * 
     * @return value20
     */
    public java.lang.String getValue20() {
        return value20;
    }


    /**
     * Sets the value20 value for this Line.
     * 
     * @param value20
     */
    public void setValue20(java.lang.String value20) {
        this.value20 = value20;
    }


    /**
     * Gets the value21 value for this Line.
     * 
     * @return value21
     */
    public java.lang.String getValue21() {
        return value21;
    }


    /**
     * Sets the value21 value for this Line.
     * 
     * @param value21
     */
    public void setValue21(java.lang.String value21) {
        this.value21 = value21;
    }


    /**
     * Gets the value22 value for this Line.
     * 
     * @return value22
     */
    public java.lang.String getValue22() {
        return value22;
    }


    /**
     * Sets the value22 value for this Line.
     * 
     * @param value22
     */
    public void setValue22(java.lang.String value22) {
        this.value22 = value22;
    }


    /**
     * Gets the value23 value for this Line.
     * 
     * @return value23
     */
    public java.lang.String getValue23() {
        return value23;
    }


    /**
     * Sets the value23 value for this Line.
     * 
     * @param value23
     */
    public void setValue23(java.lang.String value23) {
        this.value23 = value23;
    }


    /**
     * Gets the value24 value for this Line.
     * 
     * @return value24
     */
    public java.lang.String getValue24() {
        return value24;
    }


    /**
     * Sets the value24 value for this Line.
     * 
     * @param value24
     */
    public void setValue24(java.lang.String value24) {
        this.value24 = value24;
    }


    /**
     * Gets the value25 value for this Line.
     * 
     * @return value25
     */
    public java.lang.String getValue25() {
        return value25;
    }


    /**
     * Sets the value25 value for this Line.
     * 
     * @param value25
     */
    public void setValue25(java.lang.String value25) {
        this.value25 = value25;
    }


    /**
     * Gets the value26 value for this Line.
     * 
     * @return value26
     */
    public java.lang.String getValue26() {
        return value26;
    }


    /**
     * Sets the value26 value for this Line.
     * 
     * @param value26
     */
    public void setValue26(java.lang.String value26) {
        this.value26 = value26;
    }


    /**
     * Gets the value27 value for this Line.
     * 
     * @return value27
     */
    public java.lang.String getValue27() {
        return value27;
    }


    /**
     * Sets the value27 value for this Line.
     * 
     * @param value27
     */
    public void setValue27(java.lang.String value27) {
        this.value27 = value27;
    }


    /**
     * Gets the value28 value for this Line.
     * 
     * @return value28
     */
    public java.lang.String getValue28() {
        return value28;
    }


    /**
     * Sets the value28 value for this Line.
     * 
     * @param value28
     */
    public void setValue28(java.lang.String value28) {
        this.value28 = value28;
    }


    /**
     * Gets the value29 value for this Line.
     * 
     * @return value29
     */
    public java.lang.String getValue29() {
        return value29;
    }


    /**
     * Sets the value29 value for this Line.
     * 
     * @param value29
     */
    public void setValue29(java.lang.String value29) {
        this.value29 = value29;
    }


    /**
     * Gets the value30 value for this Line.
     * 
     * @return value30
     */
    public java.lang.String getValue30() {
        return value30;
    }


    /**
     * Sets the value30 value for this Line.
     * 
     * @param value30
     */
    public void setValue30(java.lang.String value30) {
        this.value30 = value30;
    }


    /**
     * Gets the value31 value for this Line.
     * 
     * @return value31
     */
    public java.lang.String getValue31() {
        return value31;
    }


    /**
     * Sets the value31 value for this Line.
     * 
     * @param value31
     */
    public void setValue31(java.lang.String value31) {
        this.value31 = value31;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Line)) return false;
        Line other = (Line) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.lineType==null && other.getLineType()==null) || 
             (this.lineType!=null &&
              this.lineType.equals(other.getLineType()))) &&
            ((this.from==null && other.getFrom()==null) || 
             (this.from!=null &&
              this.from.equals(other.getFrom()))) &&
            ((this.value1==null && other.getValue1()==null) || 
             (this.value1!=null &&
              this.value1.equals(other.getValue1()))) &&
            ((this.value2==null && other.getValue2()==null) || 
             (this.value2!=null &&
              this.value2.equals(other.getValue2()))) &&
            ((this.value3==null && other.getValue3()==null) || 
             (this.value3!=null &&
              this.value3.equals(other.getValue3()))) &&
            ((this.value4==null && other.getValue4()==null) || 
             (this.value4!=null &&
              this.value4.equals(other.getValue4()))) &&
            ((this.value5==null && other.getValue5()==null) || 
             (this.value5!=null &&
              this.value5.equals(other.getValue5()))) &&
            ((this.value6==null && other.getValue6()==null) || 
             (this.value6!=null &&
              this.value6.equals(other.getValue6()))) &&
            ((this.value7==null && other.getValue7()==null) || 
             (this.value7!=null &&
              this.value7.equals(other.getValue7()))) &&
            ((this.value8==null && other.getValue8()==null) || 
             (this.value8!=null &&
              this.value8.equals(other.getValue8()))) &&
            ((this.value9==null && other.getValue9()==null) || 
             (this.value9!=null &&
              this.value9.equals(other.getValue9()))) &&
            ((this.value10==null && other.getValue10()==null) || 
             (this.value10!=null &&
              this.value10.equals(other.getValue10()))) &&
            ((this.value11==null && other.getValue11()==null) || 
             (this.value11!=null &&
              this.value11.equals(other.getValue11()))) &&
            ((this.value12==null && other.getValue12()==null) || 
             (this.value12!=null &&
              this.value12.equals(other.getValue12()))) &&
            ((this.value13==null && other.getValue13()==null) || 
             (this.value13!=null &&
              this.value13.equals(other.getValue13()))) &&
            ((this.value14==null && other.getValue14()==null) || 
             (this.value14!=null &&
              this.value14.equals(other.getValue14()))) &&
            ((this.value15==null && other.getValue15()==null) || 
             (this.value15!=null &&
              this.value15.equals(other.getValue15()))) &&
            ((this.value16==null && other.getValue16()==null) || 
             (this.value16!=null &&
              this.value16.equals(other.getValue16()))) &&
            ((this.value17==null && other.getValue17()==null) || 
             (this.value17!=null &&
              this.value17.equals(other.getValue17()))) &&
            ((this.value18==null && other.getValue18()==null) || 
             (this.value18!=null &&
              this.value18.equals(other.getValue18()))) &&
            ((this.value19==null && other.getValue19()==null) || 
             (this.value19!=null &&
              this.value19.equals(other.getValue19()))) &&
            ((this.value20==null && other.getValue20()==null) || 
             (this.value20!=null &&
              this.value20.equals(other.getValue20()))) &&
            ((this.value21==null && other.getValue21()==null) || 
             (this.value21!=null &&
              this.value21.equals(other.getValue21()))) &&
            ((this.value22==null && other.getValue22()==null) || 
             (this.value22!=null &&
              this.value22.equals(other.getValue22()))) &&
            ((this.value23==null && other.getValue23()==null) || 
             (this.value23!=null &&
              this.value23.equals(other.getValue23()))) &&
            ((this.value24==null && other.getValue24()==null) || 
             (this.value24!=null &&
              this.value24.equals(other.getValue24()))) &&
            ((this.value25==null && other.getValue25()==null) || 
             (this.value25!=null &&
              this.value25.equals(other.getValue25()))) &&
            ((this.value26==null && other.getValue26()==null) || 
             (this.value26!=null &&
              this.value26.equals(other.getValue26()))) &&
            ((this.value27==null && other.getValue27()==null) || 
             (this.value27!=null &&
              this.value27.equals(other.getValue27()))) &&
            ((this.value28==null && other.getValue28()==null) || 
             (this.value28!=null &&
              this.value28.equals(other.getValue28()))) &&
            ((this.value29==null && other.getValue29()==null) || 
             (this.value29!=null &&
              this.value29.equals(other.getValue29()))) &&
            ((this.value30==null && other.getValue30()==null) || 
             (this.value30!=null &&
              this.value30.equals(other.getValue30()))) &&
            ((this.value31==null && other.getValue31()==null) || 
             (this.value31!=null &&
              this.value31.equals(other.getValue31())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getLineType() != null) {
            _hashCode += getLineType().hashCode();
        }
        if (getFrom() != null) {
            _hashCode += getFrom().hashCode();
        }
        if (getValue1() != null) {
            _hashCode += getValue1().hashCode();
        }
        if (getValue2() != null) {
            _hashCode += getValue2().hashCode();
        }
        if (getValue3() != null) {
            _hashCode += getValue3().hashCode();
        }
        if (getValue4() != null) {
            _hashCode += getValue4().hashCode();
        }
        if (getValue5() != null) {
            _hashCode += getValue5().hashCode();
        }
        if (getValue6() != null) {
            _hashCode += getValue6().hashCode();
        }
        if (getValue7() != null) {
            _hashCode += getValue7().hashCode();
        }
        if (getValue8() != null) {
            _hashCode += getValue8().hashCode();
        }
        if (getValue9() != null) {
            _hashCode += getValue9().hashCode();
        }
        if (getValue10() != null) {
            _hashCode += getValue10().hashCode();
        }
        if (getValue11() != null) {
            _hashCode += getValue11().hashCode();
        }
        if (getValue12() != null) {
            _hashCode += getValue12().hashCode();
        }
        if (getValue13() != null) {
            _hashCode += getValue13().hashCode();
        }
        if (getValue14() != null) {
            _hashCode += getValue14().hashCode();
        }
        if (getValue15() != null) {
            _hashCode += getValue15().hashCode();
        }
        if (getValue16() != null) {
            _hashCode += getValue16().hashCode();
        }
        if (getValue17() != null) {
            _hashCode += getValue17().hashCode();
        }
        if (getValue18() != null) {
            _hashCode += getValue18().hashCode();
        }
        if (getValue19() != null) {
            _hashCode += getValue19().hashCode();
        }
        if (getValue20() != null) {
            _hashCode += getValue20().hashCode();
        }
        if (getValue21() != null) {
            _hashCode += getValue21().hashCode();
        }
        if (getValue22() != null) {
            _hashCode += getValue22().hashCode();
        }
        if (getValue23() != null) {
            _hashCode += getValue23().hashCode();
        }
        if (getValue24() != null) {
            _hashCode += getValue24().hashCode();
        }
        if (getValue25() != null) {
            _hashCode += getValue25().hashCode();
        }
        if (getValue26() != null) {
            _hashCode += getValue26().hashCode();
        }
        if (getValue27() != null) {
            _hashCode += getValue27().hashCode();
        }
        if (getValue28() != null) {
            _hashCode += getValue28().hashCode();
        }
        if (getValue29() != null) {
            _hashCode += getValue29().hashCode();
        }
        if (getValue30() != null) {
            _hashCode += getValue30().hashCode();
        }
        if (getValue31() != null) {
            _hashCode += getValue31().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Line.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Line"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lineType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "LineType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.xignite.com/services/", "LineTypes"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("from");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "From"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value3");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value4");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value5");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value5"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value6");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value6"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value7");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value7"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value8");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value8"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value9");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value9"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value10");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value10"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value11");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value11"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value12");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value12"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value13");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value13"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value14");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value14"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value15");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value15"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value16");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value16"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value17");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value17"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value18");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value18"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value19");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value19"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value20");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value20"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value21");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value21"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value22");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value22"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value23");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value23"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value24");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value24"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value25");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value25"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value26");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value26"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value27");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value27"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value28");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value28"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value29");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value29"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value30");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value30"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value31");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.xignite.com/services/", "Value31"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

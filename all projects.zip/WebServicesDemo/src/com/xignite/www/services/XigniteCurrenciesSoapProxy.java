package com.xignite.www.services;

public class XigniteCurrenciesSoapProxy implements com.xignite.www.services.XigniteCurrenciesSoap {
  private String _endpoint = null;
  private com.xignite.www.services.XigniteCurrenciesSoap xigniteCurrenciesSoap = null;
  
  public XigniteCurrenciesSoapProxy() {
    _initXigniteCurrenciesSoapProxy();
  }
  
  public XigniteCurrenciesSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initXigniteCurrenciesSoapProxy();
  }
  
  private void _initXigniteCurrenciesSoapProxy() {
    try {
      xigniteCurrenciesSoap = (new com.xignite.www.services.XigniteCurrenciesLocator()).getXigniteCurrenciesSoap();
      if (xigniteCurrenciesSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)xigniteCurrenciesSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)xigniteCurrenciesSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (xigniteCurrenciesSoap != null)
      ((javax.xml.rpc.Stub)xigniteCurrenciesSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.xignite.www.services.XigniteCurrenciesSoap getXigniteCurrenciesSoap() {
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap;
  }
  
  public com.xignite.www.services.CurrencyList listCurrencies() throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.listCurrencies();
  }
  
  public com.xignite.www.services.CurrencyList listActiveCurrencies() throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.listActiveCurrencies();
  }
  
  public com.xignite.www.services.OfficialRates listOfficialRates() throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.listOfficialRates();
  }
  
  public com.xignite.www.services.UnitOfAccount getUnitOfAccount(java.lang.String currency, java.lang.String asOfDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getUnitOfAccount(currency, asOfDate);
  }
  
  public com.xignite.www.services.ExchangeConversion convertRealTimeValue(java.lang.String from, java.lang.String to, double amount) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.convertRealTimeValue(from, to, amount);
  }
  
  public com.xignite.www.services.ExchangeConversion convertHistoricalValue(java.lang.String from, java.lang.String to, java.lang.String asOfDate, double amount) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.convertHistoricalValue(from, to, asOfDate, amount);
  }
  
  public com.xignite.www.services.ForwardRate getRealTimeForwardRate(java.lang.String from, java.lang.String to) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getRealTimeForwardRate(from, to);
  }
  
  public com.xignite.www.services.CrossRate getRealTimeCrossRateAsString(java.lang.String from, java.lang.String to) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getRealTimeCrossRateAsString(from, to);
  }
  
  public com.xignite.www.services.CrossRate getLatestCrossRate(java.lang.String from, java.lang.String to) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getLatestCrossRate(from, to);
  }
  
  public com.xignite.www.services.CrossRate[] getLatestCrossRates(java.lang.String from, java.lang.String tos) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getLatestCrossRates(from, tos);
  }
  
  public com.xignite.www.services.CrossRate getRealTimeCrossRate(com.xignite.www.services.Currencies from, com.xignite.www.services.Currencies to) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getRealTimeCrossRate(from, to);
  }
  
  public com.xignite.www.services.CrossRate getRealTimeCrossRateGMT(com.xignite.www.services.Currencies from, com.xignite.www.services.Currencies to) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getRealTimeCrossRateGMT(from, to);
  }
  
  public com.xignite.www.services.CrossRate getRawCrossRate(com.xignite.www.services.Currencies from, com.xignite.www.services.Currencies to) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getRawCrossRate(from, to);
  }
  
  public com.xignite.www.services.CrossRate[] getRawCrossRates(java.lang.String symbols) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getRawCrossRates(symbols);
  }
  
  public com.xignite.www.services.CrossRate[] getRealTimeCrossRates(java.lang.String symbols) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getRealTimeCrossRates(symbols);
  }
  
  public com.xignite.www.services.CrossRateTable[] getHistoricalCrossRateTables(java.lang.String symbols, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getHistoricalCrossRateTables(symbols, startDate, endDate);
  }
  
  public com.xignite.www.services.CrossRateTableWithBidAsk[] getHistoricalCrossRateTablesBidAsk(java.lang.String symbols, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getHistoricalCrossRateTablesBidAsk(symbols, startDate, endDate);
  }
  
  public com.xignite.www.services.Report getCurrencyReport(java.lang.String from, java.lang.String to, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getCurrencyReport(from, to, startDate, endDate);
  }
  
  public com.xignite.www.services.CrossRateTable getHistoricalCrossRateTable(java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getHistoricalCrossRateTable(symbols, asOfDate);
  }
  
  public com.xignite.www.services.CrossRateTableWithBidAsk getHistoricalCrossRateTableBidAsk(java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getHistoricalCrossRateTableBidAsk(symbols, asOfDate);
  }
  
  public com.xignite.www.services.CrossRateTable getRealTimeCrossRateTable(java.lang.String symbols) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getRealTimeCrossRateTable(symbols);
  }
  
  public com.xignite.www.services.CrossRateTableWithBidAsk getRealTimeCrossRateTableWithBidAsk(java.lang.String symbols) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getRealTimeCrossRateTableWithBidAsk(symbols);
  }
  
  public com.xignite.www.services.CrossRateTableLineWithBidAsk getAllCrossRatesForACurrency(java.lang.String symbol) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getAllCrossRatesForACurrency(symbol);
  }
  
  public com.xignite.www.services.HTMLCrossRateTable getRealTimeCrossRateTableAsHTML(java.lang.String symbols, java.lang.String columnHeaderStyle, java.lang.String lineHeaderStyle, java.lang.String cellStyle) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getRealTimeCrossRateTableAsHTML(symbols, columnHeaderStyle, lineHeaderStyle, cellStyle);
  }
  
  public com.xignite.www.services.HTMLCrossRateTable getSimpleRealTimeCrossRateTableAsHTML(java.lang.String symbols, java.lang.String columnHeaderStyle, java.lang.String lineHeaderStyle, java.lang.String cellStyle) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getSimpleRealTimeCrossRateTableAsHTML(symbols, columnHeaderStyle, lineHeaderStyle, cellStyle);
  }
  
  public com.xignite.www.services.HTMLCrossRateTable getHistoricalCrossRateTableAsHTML(java.lang.String symbols, java.lang.String asOfDate, java.lang.String columnHeaderStyle, java.lang.String lineHeaderStyle, java.lang.String cellStyle) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getHistoricalCrossRateTableAsHTML(symbols, asOfDate, columnHeaderStyle, lineHeaderStyle, cellStyle);
  }
  
  public com.xignite.www.services.HistoricalCrossRate getHistoricalCrossRate(java.lang.String symbol, java.lang.String asOfDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getHistoricalCrossRate(symbol, asOfDate);
  }
  
  public com.xignite.www.services.HistoricalCrossRate[] getHistoricalCrossRates(java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getHistoricalCrossRates(symbols, asOfDate);
  }
  
  public com.xignite.www.services.FullHistoricalCrossRate getHistoricalCrossRateBidAsk(java.lang.String symbol, java.lang.String asOfDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getHistoricalCrossRateBidAsk(symbol, asOfDate);
  }
  
  public com.xignite.www.services.FullHistoricalCrossRate[] getHistoricalCrossRatesBidAsk(java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getHistoricalCrossRatesBidAsk(symbols, asOfDate);
  }
  
  public com.xignite.www.services.HistoricalCrossRates getHistoricalCrossRatesRange(java.lang.String symbol, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getHistoricalCrossRatesRange(symbol, startDate, endDate);
  }
  
  public com.xignite.www.services.FullHistoricalCrossRates getHistoricalCrossRatesBidAskRange(java.lang.String symbol, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getHistoricalCrossRatesBidAskRange(symbol, startDate, endDate);
  }
  
  public com.xignite.www.services.HistoricalCrossRates getHistoricalCrossRatesAsOf(java.lang.String symbol, java.util.Calendar endDate, com.xignite.www.services.PeriodTypes periodType, int periods) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getHistoricalCrossRatesAsOf(symbol, endDate, periodType, periods);
  }
  
  public com.xignite.www.services.FullHistoricalCrossRates getHistoricalCrossRatesBidAskAsOf(java.lang.String symbol, java.util.Calendar endDate, com.xignite.www.services.PeriodTypes periodType, int periods) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getHistoricalCrossRatesBidAskAsOf(symbol, endDate, periodType, periods);
  }
  
  public com.xignite.www.services.HistoricalCrossRate getOfficialCrossRate(com.xignite.www.services.CountryTypes countryType, com.xignite.www.services.Currencies symbol, java.lang.String asOfDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getOfficialCrossRate(countryType, symbol, asOfDate);
  }
  
  public com.xignite.www.services.HistoricalCrossRate[] getOfficialCrossRates(com.xignite.www.services.CountryTypes countryType, java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getOfficialCrossRates(countryType, symbols, asOfDate);
  }
  
  public com.xignite.www.services.FullHistoricalCrossRate getOfficialCrossRateBidAsk(com.xignite.www.services.CountryTypes countryType, com.xignite.www.services.Currencies symbol, java.lang.String asOfDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getOfficialCrossRateBidAsk(countryType, symbol, asOfDate);
  }
  
  public com.xignite.www.services.FullHistoricalCrossRate[] getOfficialCrossRatesBidAsk(com.xignite.www.services.CountryTypes countryType, java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getOfficialCrossRatesBidAsk(countryType, symbols, asOfDate);
  }
  
  public com.xignite.www.services.MultipleHistoricalCrossRates getMutipleHistoricalCrossRates(java.lang.String symbols, java.lang.String asOfDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getMutipleHistoricalCrossRates(symbols, asOfDate);
  }
  
  public com.xignite.www.services.AverageHistoricalCrossRate[] getAverageHistoricalCrossRates(java.lang.String symbols, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getAverageHistoricalCrossRates(symbols, startDate, endDate);
  }
  
  public com.xignite.www.services.AverageHistoricalCrossRate getAverageHistoricalCrossRate(java.lang.String symbol, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getAverageHistoricalCrossRate(symbol, startDate, endDate);
  }
  
  public com.xignite.www.services.FullHistoricalCrossRates getHistoricalMonthlyCrossRatesRange(java.lang.String symbol, java.lang.String startDate, java.lang.String endDate) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getHistoricalMonthlyCrossRatesRange(symbol, startDate, endDate);
  }
  
  public com.xignite.www.services.CrossRateChange getCrossRateChange(java.lang.String symbol) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getCrossRateChange(symbol);
  }
  
  public com.xignite.www.services.HistoricalChart getCurrencyChartCustom(java.lang.String symbol, com.xignite.www.services.HistoricalPeriodTypes periodType, java.lang.String startDate, java.lang.String endDate, com.xignite.www.services.StockChartStyles style, int width, int height, com.xignite.www.services.ChartDesign design) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getCurrencyChartCustom(symbol, periodType, startDate, endDate, style, width, height, design);
  }
  
  public com.xignite.www.services.ChartBinary getCurrencyChartCustomBinary(java.lang.String symbol, com.xignite.www.services.HistoricalPeriodTypes periodType, java.lang.String startDate, java.lang.String endDate, com.xignite.www.services.StockChartStyles style, int width, int height, com.xignite.www.services.ChartDesign design) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getCurrencyChartCustomBinary(symbol, periodType, startDate, endDate, style, width, height, design);
  }
  
  public com.xignite.www.services.HistoricalChart getCurrencyChart(java.lang.String symbol, com.xignite.www.services.HistoricalPeriodTypes periodType, java.lang.String startDate, java.lang.String endDate, com.xignite.www.services.StockChartStyles style, int width, int height, java.lang.String preset) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getCurrencyChart(symbol, periodType, startDate, endDate, style, width, height, preset);
  }
  
  public com.xignite.www.services.ChartBinary getCurrencyChartBinary(java.lang.String symbol, com.xignite.www.services.HistoricalPeriodTypes periodType, java.lang.String startDate, java.lang.String endDate, com.xignite.www.services.StockChartStyles style, int width, int height, java.lang.String preset) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getCurrencyChartBinary(symbol, periodType, startDate, endDate, style, width, height, preset);
  }
  
  public com.xignite.www.services.CurrencyChartIntraday getCurrencyIntradayChart(java.lang.String symbol, java.lang.String startTime, java.lang.String endTime, java.lang.String timeZone, com.xignite.www.services.StockChartStyles style, int width, int height, java.lang.String periodType, int tickPeriods, java.lang.String preset) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getCurrencyIntradayChart(symbol, startTime, endTime, timeZone, style, width, height, periodType, tickPeriods, preset);
  }
  
  public com.xignite.www.services.ChartBinary getCurrencyIntradayChartCustomBinary(java.lang.String symbol, java.lang.String startTime, java.lang.String endTime, java.lang.String timeZone, com.xignite.www.services.StockChartStyles style, int width, int height, java.lang.String periodType, int tickPeriods, com.xignite.www.services.ChartDesign design) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getCurrencyIntradayChartCustomBinary(symbol, startTime, endTime, timeZone, style, width, height, periodType, tickPeriods, design);
  }
  
  public com.xignite.www.services.CurrencyChartIntraday getCurrencyIntradayChartCustom(java.lang.String symbol, java.lang.String startTime, java.lang.String endTime, java.lang.String timeZone, com.xignite.www.services.StockChartStyles style, int width, int height, java.lang.String periodType, int tickPeriods, com.xignite.www.services.ChartDesign design) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getCurrencyIntradayChartCustom(symbol, startTime, endTime, timeZone, style, width, height, periodType, tickPeriods, design);
  }
  
  public com.xignite.www.services.ChartDesign getChartDesign() throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getChartDesign();
  }
  
  public com.xignite.www.services.SingleTick getTick(java.lang.String symbol, java.lang.String time) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getTick(symbol, time);
  }
  
  public com.xignite.www.services.Ticks getTicks(java.lang.String symbol, java.lang.String startTime, java.lang.String endTime, com.xignite.www.services.TickPeriod tickPrecision, int tickPeriods) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getTicks(symbol, startTime, endTime, tickPrecision, tickPeriods);
  }
  
  public com.xignite.www.services.Ticks getHistoricalTicks(java.lang.String symbol, java.lang.String startTime, java.lang.String endTime, java.lang.String asOfDate, com.xignite.www.services.TickPeriod tickPrecision, int tickPeriods) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getHistoricalTicks(symbol, startTime, endTime, asOfDate, tickPrecision, tickPeriods);
  }
  
  public com.xignite.www.services.HighLowTick getHistoricalHighLow(java.lang.String symbol, java.lang.String startDateTime, java.lang.String endDateTime) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getHistoricalHighLow(symbol, startDateTime, endDateTime);
  }
  
  public com.xignite.www.services.HighLowTick getIntradayHighLow(java.lang.String symbol, java.lang.String startDateTime, java.lang.String endDateTime) throws java.rmi.RemoteException{
    if (xigniteCurrenciesSoap == null)
      _initXigniteCurrenciesSoapProxy();
    return xigniteCurrenciesSoap.getIntradayHighLow(symbol, startDateTime, endDateTime);
  }
  
  
}
package webservicedemo;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class Client {
	public static void main(String[] args) throws Exception {
		URL url = new URL("http://172.21.142.43:8182/ws/hello?wsdl");
		
		QName qname = new QName("http://webservicedemo/", "HelloWorldImplService");
		Service service = Service.create(url,qname);
		HelloWorld hello = (HelloWorld) service.getPort(HelloWorld.class);
		System.out.println(hello.getHelloWorldAsString("Hello Web Services"));
	}
	

}

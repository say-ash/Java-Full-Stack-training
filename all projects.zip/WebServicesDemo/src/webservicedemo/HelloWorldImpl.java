package webservicedemo;

import javax.jws.WebService;

@WebService(endpointInterface = "webservicedemo.HelloWorld")
public class HelloWorldImpl implements HelloWorld{
	@Override
	public String getHelloWorldAsString(String name) {		
		return "Hello JAX-WS" + name;
	}
}

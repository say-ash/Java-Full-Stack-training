package webservicedemo;

import javax.xml.ws.Endpoint;

public class HelloPublisher {
	public static void main(String[] args) {
		Endpoint.publish("http://172.21.142.43:8182/ws/hello", new HelloWorldImpl());
	}
}

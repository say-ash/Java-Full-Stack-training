package com.practice;

import java.util.ArrayList;
import java.util.List;


public class StreamDemo {

	public static void main(String[] args) {
		List<Employee> empList = new ArrayList<>();
		empList.add(new Employee(1,"ash","mumbai"));
		empList.add(new Employee(2,"divya","mumbai"));
		empList.add(new Employee(3,"ash","mumbai"));
		empList.add(new Employee(4,"monika","pune"));
		empList.add(new Employee(5,"sharad","UP"));
		
		System.out.println(empList.stream().filter(d->d.getId()==5).findFirst().get());
		System.out.println(empList.parallelStream().findFirst().get());
	}
}

package springBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import springBoot.dao.EmployeeDao;
import springBoot.entity.Employee;

@Service
public class EmployeeService {

	public EmployeeService() {
	}
	
	@Autowired
	private EmployeeDao empDao;
	
	public void addEmployee(Employee employee) {
		empDao.addEmployee(employee);
	}
	
	public List<Employee> getEmployee(){
		return empDao.getEmployee();
	}
}

package springBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import springBoot.entity.Employee;
import springBoot.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService empService;
	
	public EmployeeController() {
	}
	
	/*@Value("${}")
	private String developerName;*/
	
	@PostMapping("/addEmployee")
	public String addEmployee(@RequestBody Employee employee) {
		empService.addEmployee(employee);
		return "Employee added Successfully";
		
	}
	
	@RequestMapping("/getAllEmployeesList")
	public List<Employee> getAllEmployeesList(){
		List<Employee> empList = empService.getEmployee();
		return empList;
	}
}

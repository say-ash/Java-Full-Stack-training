package springBoot.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Repository;

import springBoot.entity.Employee;

@Repository
public class EmployeeDao {

	private List<Employee> list = new ArrayList<Employee>(
			Arrays.asList(new Employee(1, "ashraf", "mumbai"), new Employee(2, "divya", "pune"),
					new Employee(3, "monika", "hydrabad"), new Employee(4, "isaac", "bangalore")));

	public EmployeeDao() {
	}

	public void addEmployee(Employee employee) {
		list.add(employee);
		for(Employee e:list)
			System.out.println("Employee Added(in dao): " + employee);

	}

	public List<Employee> getEmployee() {
		return list;
	}
}

package com.lti.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



@Entity
@Table(name="ADDRESS")
public class Address1 {
	@Id
	@GeneratedValue(generator="gen")
	@SequenceGenerator(initialValue=1,sequenceName="gen", name = "seq")
	@Column(name="ADDRESS_ID")
	private long id;
	
	@Column(name="STREET_NAME")
	private String street;
	
	@Column(name="ZIPCODE")
	private String zipcode;
	
	@Column(name="CITY_NAME")
	private String city;

	@OneToOne(mappedBy="address")
	@PrimaryKeyJoinColumn
	private User user;

	public long getId() {
		return id;
	}

	public Address1() {
		// TODO Auto-generated constructor stub
	}

	public Address1(long id, String street, String zipcode, String city, User user) {
		super();
		this.id = id;
		this.street = street;
		this.zipcode = zipcode;
		this.city = city;
		this.user = user;
	}


	public Address1(String street, String zipcode, String city) {
		this.street = street;
		this.zipcode = zipcode;
		this.city = city;

	}

	public void setId(long id) {
		this.id = id;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Address1 [id=" + id + ", street=" + street + ", zipcode=" + zipcode + ", city=" + city+" ]";
	}



}

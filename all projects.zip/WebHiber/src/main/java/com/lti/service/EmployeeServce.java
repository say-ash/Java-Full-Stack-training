package com.lti.service;

import com.lti.dao.EmployeeDao;
import com.lti.entity.Employee;
import com.lti.entity.EmployeeAnnotation;

public class EmployeeServce {

	public int addEmployee(EmployeeAnnotation employee) {
		System.out.println(employee);
		employee.setCity("pune");
		EmployeeDao dao=new EmployeeDao();
		int res = dao.saveEmployee(employee);
		return 1;
	}
}

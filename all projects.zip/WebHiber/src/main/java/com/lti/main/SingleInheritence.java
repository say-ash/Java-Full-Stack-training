package com.lti.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.lti.entity.ActiveEmployee;
import com.lti.entity.EmployeeInheritenceSingle;
import com.lti.entity.RetiredEmployee;

public class SingleInheritence {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("lntdemo");
		System.out.println("factory");
		
		EntityManager em= emf.createEntityManager();
		EntityTransaction etx=em.getTransaction();
		etx.begin();
		      
		/*ActiveEmployee ae1=new ActiveEmployee(101,"Karun",10000,5);  
		ActiveEmployee ae2=new ActiveEmployee(102,"Rishab",12000,7);  
		  
		RetiredEmployee re1=new RetiredEmployee(103,"Ramesh",5000);  
		RetiredEmployee re2=new RetiredEmployee(104,"Raj",4000);  
		  
		    em.persist(ae1);  
		    em.persist(ae2);  
		      
		    em.persist(re1);  
		    em.persist(re2);  */
		    
		    
		    EmployeeInheritenceSingle ee =  em.find(ActiveEmployee.class, 101);
		    
		    System.out.println(ee);
		      
		    etx.commit();  
		      
		    em.close();  
		    emf.close();  

	}

}

package com.lti.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
public class MyDataSource {
	private static SessionFactory factory;

	public static SessionFactory getFactory() {
		return factory;	
	}
	static {
		Configuration conf=new Configuration();
		conf.configure();
		System.out.println("configure");
		factory= conf.buildSessionFactory();

	}
}

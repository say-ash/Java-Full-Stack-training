package com.sharad.hello;

import javax.jws.WebService;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;

@WebService
@Path("/")
public class HelloWorld {

	@GET
	@Path("/get1")
	public String helloget1() {
		return "Hello Rest World - GET1";
	}
	@GET
	@Path("/get2")
	public String helloget2() {
		return "Hello Rest World - GET2";
	}
	
	@POST
	@Path("/post1")
	public String hellopost() {
		return "Hello Rest World - POST";
	}
	@PUT
	@Path("/put1")
	public String helloput() {
		return "Hello Rest World - PUT";
	}
	@DELETE
	public String hellodelete() {
		return "Hello Rest World - DELETE";
	}
	
}

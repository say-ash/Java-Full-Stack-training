package com.practice;

import java.awt.Frame;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;



class MyGUI{
	
	public MyGUI() {
	
		WindowAdapter wa = new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				super.windowClosing(e);
			}
		};
		Frame frame = new Frame();
		frame.setSize(200, 300);
		frame.setVisible(true);
		Label l = new Label();
		l.setText("hello");
		frame.add(l);
		TextArea ta = new TextArea();
		frame.add(ta);
		frame.addWindowListener(wa);
	}
}

public class AdapterDemo {

	public static void main(String[] args) {
		new MyGUI();

	}
}

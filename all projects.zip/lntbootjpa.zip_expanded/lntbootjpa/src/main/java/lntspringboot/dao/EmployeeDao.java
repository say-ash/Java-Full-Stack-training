package lntspringboot.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import lntspringboot.model.Employee;
import lntspringboot.repo.EmployeeRepository;

@Repository
public class EmployeeDao {
	@Autowired
	private EmployeeRepository emprepository;

	private List<Employee> emplist = new ArrayList<>(Arrays.asList(new Employee(1, "yash", "mumbai"),
			new Employee(2, "raj", "navi mumbai"), new Employee(3, "om", "panvel")));

	public EmployeeDao() {
		System.out.println("Employee Dao");
	}

	public Employee addEmployee(Employee employee) {
		Employee employe = emprepository.save(employee);

		// emplist.add(employee);
		System.out.println("Employee added: " + employe);
		return employe;
	}

	public List<Employee> getAllEmployees() {
		List<Employee> list = (List<Employee>) emprepository.findAll();
		return list;
	}

	public Optional<Employee> getEmployee(int id) {
		/* Employee emp=emplist.stream().filter(x->x.getId()==id).findFirst().get(); */
		/*
		 * for(Employee ee:emplist) { if(ee.getId()==id) { return ee; } }
		 */
		/* public Student retrieveStudent(@PathVariable long id) { */
		Optional<Employee> emp = emprepository.findById(id);
		return emp;
	}

	public void removeEmployee(int id) {
		emprepository.deleteById(id);
		System.out.println("deleted");
	}

	public Employee updateEmployee(int id) {
		Employee emp = emprepository.findById(id).get();
		System.out.println("Retreive employee: " + emp);
		/*
		 * emp.setId(id); emp.setCity(emp.getCity()); emp.setName(emp.getName());
		 */
		emp = emprepository.save(emp);
		System.out.println("updated");
		return emp;
	}

	public List<Employee> findEmployeeByName(String name) {
		List<Employee> list = emprepository.findByName(name);
		System.out.println(list);
		return list;

	}

}

package lntspringboot.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import lntspringboot.model.Employee;

public interface EmployeeRepository extends CrudRepository<Employee, Integer> {
	
	public List<Employee> findByName(String name);
	/*
	 * List<Employee>FindByname(String name);
	 */
}

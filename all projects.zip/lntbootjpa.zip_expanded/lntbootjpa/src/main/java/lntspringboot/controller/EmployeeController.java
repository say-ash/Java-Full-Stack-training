package lntspringboot.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import lntspringboot.model.Employee;
import lntspringboot.service.EmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	private EmployeeService emps;
	public EmployeeController() {
		System.out.println("Controller is created");
	}

	@RequestMapping("/getdetails")
	public List<Employee> getEmployees(){
		List<Employee> emplist=emps.getAllEmployeesList();
		return emplist;
	}

	@RequestMapping(method=RequestMethod.POST,value="/addemployee")
	public String addEmployee(@RequestBody Employee employee){
		emps.addEmployee(employee);
		return "Employee added successfully";
	}

	@RequestMapping("/getdetails/{id}")
	public Optional<Employee> getEmployee(@PathVariable int id) {
		Optional<Employee> employee=emps.getEmployee(id);
		if(!employee.isPresent())
			throw new EmployeeNotFoundException("id-"+id);
		return employee;

	}
	
	@RequestMapping("/removedetails/{id}")
	public String removeEmployee(@PathVariable int id) {
		emps.removeEmployee(id);
		return "Employee removed";
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/updatedetails/{id}")
	public Employee updateEmployee(@PathVariable int id) {
		Employee employee=emps.updateEmployee(id);
		return employee;
		
	}
	
	@RequestMapping("/getEmployeeByName/{name}")
	public List<Employee> getEmployeeByName(@PathVariable String name){
		return emps.findEmployeeByName(name);
	}


}

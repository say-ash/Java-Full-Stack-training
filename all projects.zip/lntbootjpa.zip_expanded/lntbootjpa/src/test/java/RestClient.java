import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;

import lntspringboot.model.Employee;

public class RestClient {

	public static void main(String[] args) {
		Myfunction();
	}
	public static void Myfunction(){
		
		RestTemplate restTemplate = new RestTemplate();
		Employee employee = restTemplate.getForObject("http://localhost:9110/getdetails/3", Employee.class);
		System.out.println(employee);
	}
}

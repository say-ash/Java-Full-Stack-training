package com.security.spring.securityDemo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService emps;
	public EmployeeController() {
		System.out.println("Controller is created");
	}

	@RequestMapping("/getdetails")
	public List<Employee> getEmployees(){
		List<Employee> emplist=emps.getAllEmployeesList();
		return emplist;
	}

	@RequestMapping(method=RequestMethod.GET,value="/addemployee")
	public ModelAndView show() {
		return new ModelAndView("addEmployee","emp",new Employee());
	}
	
	
	@RequestMapping(method=RequestMethod.POST,value="/addemployee")
	public ModelAndView processRequest(@ModelAttribute("emp") Employee emp) {
		emps.addEmployee(emp);
		List<Employee> employee=emps.getAllEmployeesList();
		ModelAndView mv= new ModelAndView(employee);
		return mv;
	}
	
	
	@RequestMapping("/getdetails/{id}")
	public Optional<Employee> getEmployee(@PathVariable int id) {
		Optional<Employee> employee=emps.getEmployee(id);
		return employee;

	}
	
	@RequestMapping("/removedetails/{id}")
	public String removeEmployee(@PathVariable int id) {
		emps.removeEmployee(id);
		return "Employee removed";
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/updatedetails/{id}")
	public Employee updateEmployee(@PathVariable int id) {
		Employee employee=emps.updateEmployee(id);
		return employee;
		
	}
	
	@RequestMapping("/getEmployeeByName/{name}")
	public List<Employee> getEmployeeByName(@PathVariable String name){
		return emps.findEmployeeByName(name);
	}


}

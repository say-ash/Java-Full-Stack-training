package com.security.spring.securityDemo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class EmployeeService {
	
	
	@Autowired
	private EmployeeDao empd;
	public EmployeeService() {
		System.out.println("Service is created");
	}
	public void addEmployee(Employee employee) {
		empd.addEmployee(employee);
	}
	public List<Employee> getAllEmployeesList(){
		List<Employee> emplist=empd.getAllEmployees();
		/*
		 * for(Employee ee:emplist) { System.out.println(emplist); }
		 */
		return emplist;

	}
	 
	public Optional<Employee> getEmployee(int id) {
		Optional<Employee> employee=empd.getEmployee(id);
		return employee;
	}
	public void removeEmployee(int id) {
		empd.removeEmployee(id);
	}
	public Employee updateEmployee(int id) {
		Employee employee=empd.updateEmployee(id);
		return employee;
	}
	
	public List<Employee> findEmployeeByName(String name){
		System.out.println("in emp service" +name);
		return 	empd.findEmployeeByName(name);		
	}
}

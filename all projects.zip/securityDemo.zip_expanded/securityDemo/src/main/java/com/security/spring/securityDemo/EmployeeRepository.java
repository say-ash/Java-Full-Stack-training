package com.security.spring.securityDemo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;


public interface EmployeeRepository extends CrudRepository<Employee, Integer> {
	
	public List<Employee> findByName(String name);
	/*
	 * List<Employee>FindByname(String name);
	 */
}
